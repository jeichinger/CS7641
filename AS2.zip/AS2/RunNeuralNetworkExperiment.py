from mlrose_hiive.runners import nngs_runner
from sklearn.model_selection import train_test_split
import pandas as pd
import os
import numpy as np
import mlrose_hiive.algorithms.gd
from mlrose_hiive.neural import NeuralNetwork
from DataPreprocessor import preprocess_data
from sklearn.model_selection import validation_curve
from sklearn.model_selection import GridSearchCV
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
import NeuralNetworkLearner

DATA_PATH = os.getcwd() + "/Data"
OUTPUT_PATH = os.getcwd() + "/Output"
NEURAL_NETWORK_PATH = OUTPUT_PATH + "/NN/"
GRAD_DESCENT_PATH = "/GD"


def run_neural_network_optimization_experiment(dataset_name, run_rhc, run_sa, run_ga, grid_search=False, run_gd=True):
    np.random.seed(0)

    # Load the data.
    dataset_csv_path = os.path.join(DATA_PATH, dataset_name)
    dataset = pd.read_csv(dataset_csv_path)

    X = dataset.drop("class", axis=1)
    y = dataset["class"].copy().tolist()

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1)

    pipe = preprocess_data(X_train)
    X_train_transformed = pipe.fit_transform(X_train)

    if run_gd:

        nn = NeuralNetwork(hidden_nodes=[12, 2],
                           activation='relu',
                           algorithm='gradient_descent',
                           max_iters=3000,
                           bias=True,
                           is_classifier=True,
                           early_stopping=True,
                           max_attempts=300,
                           random_state=np.random.randint(150),
                           curve=True)

        nn_gd_learner = NeuralNetworkLearner.NeuralNetworkLearner(X_train_transformed, X_test, y_train, y_test, pipe,
                                                                  nn, 'GD')
        if grid_search:

            model_params = {'learning_rate': [0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.007, 0.008, 0.009],
                            'max_iters': [1000],
                            'activation': [mlrose_hiive.relu]
                            }

            nn_gd_learner.update_and_refit_model()
            nn_gd_learner.tune_hyper_parameter('learning_rate', [0.0001, 0.0003, 0.0004, 0.0005])

        nn_gd_learner.tune_learning_rate_parameter('learning_rate',[0.0005, 0.0008, 0.0009, 0.001])
        nn_gd_learner.model.learning_rate = 0.0007
        nn_gd_learner.update_and_refit_model()

        nn_gd_learner.tune_learning_rate_parameter('max_iters',[1500, 3000, 5000])

        # generate the learning curves.
        nn_gd_curve, nn_gd_axis, nn_gd_time = nn_gd_learner.generate_learning_curves("Learning Curve")

        # Cap iters to combat overfitting
        nn_gd_learner.model.max_iters = 3000
        nn_gd_learner.update_and_refit_model()
        nn_gd_learner.run_cross_val_on_test_set()

    if run_sa:

        sa_nn = NeuralNetwork(hidden_nodes=[12, 2],
                              activation='relu',
                              algorithm='simulated_annealing',
                              max_iters=3000,
                              bias=True,
                              is_classifier=True,
                              early_stopping=True,
                              max_attempts=300,
                              random_state=np.random.randint(150),
                              curve=True)

        nn_sa_learner = NeuralNetworkLearner.NeuralNetworkLearner(X_train_transformed, X_test, y_train, y_test, pipe,
                                                                  sa_nn,
                                                                  'SA')

        if grid_search:

            temperature_list = [1, 10, 50, 100, 500, 1000]
            decay_list = [mlrose_hiive.GeomDecay, mlrose_hiive.ExpDecay, mlrose_hiive.ArithDecay]
            temperatures = [d(init_temp=t) for t in temperature_list for d in decay_list]

            # Simulated annealing
            sa_param_grid = {'schedule': temperatures,
                             'learning_rate': [0.001, 0.003, 0.005, 0.007, 0.009],
                             'max_iters': [100, 250, 500, 750, 1200, 1500]
                             }

            nn_sa_learner.update_and_refit_model()
            nn_sa_learner.find_hyper_params_coarse(sa_param_grid)

        # Generate curve for various init temp

        temperature_list = [50, 25, 15, 5, 1]
        decay_list = [mlrose_hiive.GeomDecay]
        temperatures = [d(init_temp=t) for t in temperature_list for d in decay_list]
        nn_sa_learner.tune_hyper_parameter('schedule', temperatures, "Loss with Geometric Decay \n Various Initial Temp - SA")

        # best schedule found from grid search
        best_schedule = mlrose_hiive.GeomDecay(init_temp=25)

        nn_sa_learner.model.schedule = best_schedule
        nn_sa_learner.update_and_refit_model()

        nn_sa_learner.tune_learning_rate_parameter('learning_rate', [0.1, 0.2, 0.3, 0.4, 0.5, 0.60, 0.70, 0.8, 0.9])

        # best learning rate
        nn_sa_learner.model.learning_rate = 0.30
        nn_sa_learner.update_and_refit_model()
        nn_sa_curve, nn_sa_axis, nn_sa_time = nn_sa_learner.generate_learning_curves("Learning Curve")

        nn_sa_learner.update_and_refit_model()
        nn_sa_learner.run_cross_val_on_test_set()

    if run_rhc:

        rhc_nn = NeuralNetwork(hidden_nodes=[12, 2],
                               activation='relu',
                               algorithm='random_hill_climb',
                               max_iters=3000,
                               bias=True,
                               is_classifier=True,
                               early_stopping=True,
                               max_attempts=300,
                               random_state=np.random.randint(150),
                               curve=True)

        nn_rhc_learner = NeuralNetworkLearner.NeuralNetworkLearner(X_train_transformed, X_test, y_train, y_test, pipe,
                                                                   rhc_nn,
                                                                   'RHC')

        if grid_search:

            #Randomized Hill Climbing
            rhc_param_grid = {'restarts': [10, 25, 50, 75],
                              'max_iters': [100, 250, 500, 750, 1200, 1500],
                              }

            nn_rhc_learner.update_and_refit_model()
            nn_rhc_learner.find_hyper_params_coarse(rhc_param_grid)

        nn_rhc_learner.tune_hyper_parameter('restarts', [10,25,50,75], "Loss with Various Number of Restarts - RHC")

        nn_rhc_learner.model.restarts = 10

        nn_rhc_learner.tune_learning_rate_parameter('learning_rate', [0.05, 0.1, 0.2, 0.3, 0.4])

        nn_rhc_learner.model.learning_rate = 0.40
        nn_rhc_learner.update_and_refit_model()

        nn_rhc_curve, nn_rhc_axis, nn_rhc_time = nn_rhc_learner.generate_learning_curves("Learning Curve")

        nn_rhc_learner.update_and_refit_model()
        nn_rhc_learner.run_cross_val_on_test_set()

    if run_ga:

        ga_nn = NeuralNetwork(hidden_nodes=[12, 2],
                              activation='relu',
                              algorithm='genetic_alg',
                              max_iters=3000,
                              bias=True,
                              is_classifier=True,
                              early_stopping=True,
                              max_attempts=300,
                              random_state=np.random.randint(100),
                              curve=True)

        ga_nn.mutation_prob = 0.1

        ga_nn_learner = NeuralNetworkLearner.NeuralNetworkLearner(X_train_transformed, X_test, y_train, y_test, pipe,
                                                                  ga_nn,
                                                                  'GA')

        if grid_search:

            ga_param_grid = {'mutation_prob': [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
                             'max_iters': [100, 250, 500, 750, 1200, 1500],
                             }

            ga_nn_learner.update_and_refit_model()
            ga_nn_learner.find_hyper_params_coarse(ga_param_grid)

        #ga_nn_learner.tune_hyper_parameter('population', [25, 50, 100, 150, 250],
        #                                   "Loss with Various Population - GA")

        ga_nn_learner.model.pop_size = 150

        ga_nn_learner.tune_hyper_parameter('mutation', [0.01, 0.02, 0.03, 0.04], "Loss with Pop Size 150 and Various Mutation Rates\nGA")

        ga_nn_learner.model.mutation_prob = 0.01
        ga_nn_learner.update_and_refit_model()

        #ga_nn_learner.tune_learning_rate_parameter('learning_rate', [0.0000001, 0.000001, 0.00001, 0.0001, 0.001, 0.01, 0.1])

        ga_nn_learner.model.learning_rate = 0.1

        ga_nn_learner.update_and_refit_model()
        ga_nn_curve, ga_nn_axis, ga_nn_time = ga_nn_learner.generate_learning_curves("Learning Curve")

        ga_nn_learner.update_and_refit_model()
        ga_nn_learner.run_cross_val_on_test_set()

    title_dic = {'fontsize': 7, 'fontweight': 'bold'}
    axis_label_size = 7

    fig, (fitness_cp, time_cp) = plt.subplots(1, 2, figsize=(6, 2))
    fitness_cp.set_title(
        "Loss vs Iterations \n NN Tuning", title_dic)
    fitness_cp.set_ylabel("Average Fitness Score", title_dic)
    fitness_cp.tick_params(axis="x", labelsize=axis_label_size)
    fitness_cp.tick_params(axis="y", labelsize=axis_label_size)
    fitness_cp.set_xlabel("Iteration", title_dic)

    fitness_cp.set_ylim(top=1, bottom=0.3)

    fitness_cp.plot(nn_gd_axis, nn_gd_curve, label="GD")
    fitness_cp.plot(nn_rhc_axis, nn_rhc_curve, label="RHC")
    fitness_cp.plot(nn_sa_axis, nn_sa_curve, label="SA")
    fitness_cp.plot(ga_nn_axis, ga_nn_curve, label="GA")

    fitness_cp.legend(loc='best', fontsize=6)

    time_cp.set_xlabel("Log Time (s)", title_dic)
    time_cp.set_title("Runtime For Training", title_dic)
    time_cp.set_ylabel("Algorithm", title_dic)
    time_cp.tick_params(axis="x", labelsize=axis_label_size)
    time_cp.tick_params(axis="y", labelsize=axis_label_size)

    x = ['GD', 'RHC', 'SA', 'GA']
    x_pos = [i for i, _ in enumerate(x)]
    time_cp.set_yticks(x_pos)
    time_cp.set_yticklabels(x)
    time_cp.set_xscale('log')
    time_cp.barh(x_pos, [nn_gd_time, nn_rhc_time, nn_sa_time, ga_nn_time])

    time_cp.grid()
    fitness_cp.grid()
    plt.tight_layout()

    path = NEURAL_NETWORK_PATH
    filename = "loss_vs_iteration.png"
    filename = os.path.join(path, filename)
    plt.savefig(filename)
