from CustomMDP import PolicyIteration
import matplotlib.pyplot as plt
import os
from matplotlib.ticker import FormatStrFormatter
import pickle
import numpy as np

class PolicyIterationExperiment():

    P_INDEX = 0
    R_INDEX = 1
    HYPER_PARAMS_INDEX = 2
    PROBLEM_SIZE_INDEX = 3

    def __init__(self, problems, output_dir, problem_name):

        self.problems = problems
        self.output_dir = output_dir
        self.problem_name = problem_name
        self.hyper_params = {}
        self.policies = {}
        self.times = {}
        self.max_values = {}

    def tune_hyper_parameter(self, hyper_param_name, values):

        for problem in self.problems:

            rewards_list = []
            hyper_params = problem[self.HYPER_PARAMS_INDEX]

            title = "Max Utility vs " + hyper_param_name + "\n" + self.problem_name + " Size " + problem[self.PROBLEM_SIZE_INDEX]
            title_dic = {'fontsize': 7, 'fontweight': 'bold'}
            fig, (ax1,ax2, ax3) = plt.subplots(1, 3, figsize=(9, 2))
            ax1.set_xlabel("Iterations", title_dic)
            #ax1.set_xscale('log')
            ax1.set_title(title , title_dic)
            ax1.set_ylabel("Max Utility", title_dic)
            ax1.tick_params(axis="x", labelsize=7)
            ax1.tick_params(axis="y", labelsize=7)
            ax1.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
            ax1.grid()

            title = "Policy Changes vs " + hyper_param_name + "\n" + self.problem_name + " Size " + problem[
                self.PROBLEM_SIZE_INDEX]

            ax2.set_xlabel("Iterations", title_dic)
            ax2.set_title(title, title_dic)
            ax2.set_ylabel("# Policy Changes", title_dic)
            ax2.tick_params(axis="x", labelsize=7)
            ax2.tick_params(axis="y", labelsize=7)
            ax2.grid()

            title = "Change in Utility vs " + hyper_param_name + "\n" + self.problem_name + " Size " + problem[
                self.PROBLEM_SIZE_INDEX]

            ax3.set_xlabel("Iterations", title_dic)
            ax3.set_title(title, title_dic)
            ax3.set_ylabel("Delta Utility (Log)", title_dic)
            ax3.tick_params(axis="x", labelsize=7)
            ax3.tick_params(axis="y", labelsize=7)
            #ax3.set_ylim(top=.3, bottom=0.0)

            if self.problem_name == "FrozenLake":

                if problem[self.PROBLEM_SIZE_INDEX] == '10x10':
                    ax2.set_ylim(top=50, bottom=0)
                else:
                    ax2.set_ylim(top=500, bottom=0)

            plt.tight_layout()
            plt.grid()

            if "max_iter" in hyper_params:
                iters = hyper_params["max_iter"]
            else:
                iters = 10000

            if "epsilon" in hyper_params:
                epsilon = hyper_params["epsilon"]
            else:
                epsilon = 0.0000001

            if 'gamma' in hyper_params:
                gamma = hyper_params["gamma"]
            else:
                gamma = 0.99

            for value in values:

                if hyper_param_name == 'gamma':
                    pi = PolicyIteration(problem[self.P_INDEX], problem[self.R_INDEX], gamma=value, max_iter=iters, epsilon=epsilon)
                elif hyper_param_name == 'max_iter':
                    pi = PolicyIteration(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, max_iter=value, epsilon=epsilon)
                elif hyper_param_name == 'epsilon':
                    pi = PolicyIteration(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, max_iter=iters, epsilon=value)

                stats = pi.run()

                rewards = [dict["Max V"] for dict in stats]
                changes = [dict["Changes In Policy"] for dict in stats]
                delta = [dict["Error"] for dict in stats]
                print("Max Reward with " + hyper_param_name + " value " + str(value) +  " " + str(rewards[-1]))

                iters_plot = np.arange(1, len(rewards) + 1, 1)

                ax1.plot(rewards, label=str(value))
                ax2.plot(changes, label=str(value))
                ax3.plot(delta, label=str(value))

                #rewards_list.append(rewards)

            ax3.set_yscale('log')
            ax1.legend(loc='lower right', fontsize=6, ncol=2)
            ax2.legend(loc='best', fontsize=6, ncol=2)
            ax3.legend(loc='best', fontsize=6, ncol=2)
            path = os.path.join(self.output_dir)
            filename = title + ".png"
            filename = os.path.join(path, filename)
            plt.savefig(filename)
            plt.close()

    def plot_convergence(self):

        title = "Convergence for Policy Iteration \n" + self.problem_name
        title_dic = {'fontsize': 7, 'fontweight': 'bold'}
        fig, (ax3,ax1,ax2) = plt.subplots(1, 3, figsize=(9, 2))
        ax1.set_xlabel("Iterations", title_dic)
        ax1.set_title(title, title_dic)
        ax1.set_ylabel("Delta Utility", title_dic)
        ax1.tick_params(axis="x", labelsize=7)
        ax1.tick_params(axis="y", labelsize=7)
        ax1.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
        ax1.set_yscale('log')
        ax1.grid()

        title1 = "Time (ms) vs Iterations \n" + self.problem_name
        ax2.set_xlabel("Iterations", title_dic)
        ax2.set_title(title1, title_dic)
        ax2.set_ylabel("Time(ms)", title_dic)
        ax2.tick_params(axis="x", labelsize=7)
        ax2.tick_params(axis="y", labelsize=7)
        ax2.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax2.grid()
        plt.tight_layout()
        plt.grid()

        title2 = "Max Utility vs Iterations \n" + self.problem_name
        ax3.set_xlabel("Iterations", title_dic)
        ax3.set_title(title2, title_dic)
        ax3.set_ylabel("Max Utility", title_dic)
        ax3.tick_params(axis="x", labelsize=7)
        ax3.tick_params(axis="y", labelsize=7)
        ax3.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax3.grid()
        plt.tight_layout()
        plt.grid()

        for problem in self.problems:

            hyper_params = problem[self.HYPER_PARAMS_INDEX]
            pi = PolicyIteration(problem[self.P_INDEX], problem[self.R_INDEX], gamma=hyper_params["gamma"], max_iter=hyper_params["max_iter"], epsilon=hyper_params["epsilon"])

            stats = pi.run()
            time = [dict["Time"] for dict in stats]
            time = np.array(time)
            time = time * 1000
            time_delta = np.array([x - time[i - 1] for i, x in enumerate(time)][1:])

            maxV = [dict["Max V"] for dict in stats]

            self.policies[problem[self.PROBLEM_SIZE_INDEX]] = list(pi.policy)
            self.times[problem[self.PROBLEM_SIZE_INDEX]] = time[-1]
            self.max_values[problem[self.PROBLEM_SIZE_INDEX]] = maxV

            path = os.path.join(self.output_dir)
            filename = "policyiterationrunstats" + problem[self.PROBLEM_SIZE_INDEX]
            filename = os.path.join(path, filename)

            outfile = open(filename, 'wb')
            pickle.dump(stats, outfile)
            outfile.close()


            ax3.plot(maxV, label="Size:" + str(problem[self.PROBLEM_SIZE_INDEX]))

            delta = [dict["Error"] for dict in stats]
            ax1.plot(delta, label="Size:" + str(problem[self.PROBLEM_SIZE_INDEX]))

            ax2.plot(time_delta, label="Size:" + str(problem[self.PROBLEM_SIZE_INDEX]))

                #rewards_list.append(rewards)

        ax1.legend(loc='best', fontsize=6)
        ax2.legend(loc='best', fontsize=6)
        ax3.legend(loc='best', fontsize=6)
        path = os.path.join(self.output_dir)
        filename = title + ".png"
        filename = os.path.join(path, filename)
        plt.savefig(filename)
        plt.close()

    def plot_time_to_solution_for_varying_sizes(self):
        return



