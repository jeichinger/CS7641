from CustomMDP import QLearning
import matplotlib.pyplot as plt
import os
from matplotlib.ticker import FormatStrFormatter
import pickle
import numpy as np

class QLearningExperiment():

    P_INDEX = 0
    R_INDEX = 1
    HYPER_PARAMS_INDEX = 2
    PROBLEM_SIZE_INDEX = 3

    def __init__(self, problems, output_dir, problem_name):

        self.problems = problems
        self.output_dir = output_dir
        self.problem_name = problem_name
        self.hyper_params = {}
        self.policies = {}
        self.times = {}
        self.max_values = {}

    def tune_hyper_parameter(self, hyper_param_name, values):

        if self.problem_name == 'Forest':

            for problem in self.problems:

                rewards_list = []
                hyper_params = problem[self.HYPER_PARAMS_INDEX]

                title = "Max Utility vs " + hyper_param_name + "\n" + self.problem_name + " Size " + problem[
                    self.PROBLEM_SIZE_INDEX]
                title_dic = {'fontsize': 7, 'fontweight': 'bold'}
                fig, (ax1, ax3) = plt.subplots(1, 2, figsize=(6, 2))
                ax1.set_xlabel("Iterations", title_dic)
                # ax1.set_xscale('log')
                ax1.set_title(title, title_dic)
                ax1.set_ylabel("Max Utility", title_dic)
                ax1.tick_params(axis="x", labelsize=7)
                ax1.tick_params(axis="y", labelsize=7)
                ax1.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
                ax1.grid()

                title = "Change in Utility vs " + hyper_param_name + "\n" + self.problem_name + " Size " + problem[
                    self.PROBLEM_SIZE_INDEX]

                ax3.set_xlabel("Iterations", title_dic)
                ax3.set_title(title, title_dic)
                ax3.set_ylabel("Delta Utility (Log)", title_dic)
                ax3.tick_params(axis="x", labelsize=7)
                ax3.tick_params(axis="y", labelsize=7)
                # ax3.set_ylim(top=.3, bottom=0.0)

                plt.tight_layout()
                plt.grid()

                if "n_iter" in hyper_params:
                    iters = hyper_params["n_iter"]
                else:
                    iters = 1000000

                if "epsilon" in hyper_params:
                    epsilon = hyper_params["epsilon"]
                else:
                    epsilon = 1

                if 'gamma' in hyper_params:
                    gamma = hyper_params["gamma"]
                else:
                    gamma = 0.99

                if 'alpha' in hyper_params:
                    alpha = hyper_params["alpha"]
                else:
                    alpha = 0.1

                if 'alpha_decay' in hyper_params:
                    alpha_decay = hyper_params["alpha_decay"]
                else:
                    alpha_decay = 0.99

                if 'epsilon_decay' in hyper_params:
                    epsilon_decay = hyper_params["epsilon_decay"]
                else:
                    epsilon_decay = 0.99

                for value in values:

                    if hyper_param_name == 'gamma':
                        q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=value, alpha=alpha,
                                      alpha_decay=alpha_decay, epsilon=epsilon, n_iter=iters)
                    elif hyper_param_name == 'max_iter':
                        q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, alpha=alpha,
                                      alpha_decay=alpha_decay, epsilon=epsilon, n_iter=value)
                    elif hyper_param_name == 'epsilon':
                        q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, alpha=alpha,
                                      alpha_decay=alpha_decay, epsilon=value, n_iter=iters)
                    elif hyper_param_name == 'alpha':
                        q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, alpha=value,
                                      alpha_decay=alpha_decay, epsilon=epsilon, n_iter=iters)
                    elif hyper_param_name == 'alpha_decay':
                        q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, alpha=alpha,
                                      alpha_decay=value, epsilon=epsilon, n_iter=iters)
                    elif hyper_param_name == 'epsilon_decay':
                        q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, alpha=alpha,
                                      alpha_decay=alpha_decay, epsilon=epsilon, epsilon_decay=value, n_iter=iters)

                    stats = q.run()

                    rewards = np.asarray([dict["Max V"] for dict in stats])
                    iterations = [dict["Iteration"] for dict in stats]
                    # changes = [dict["Changes In Policy"] for dict in stats]
                    delta = [dict["Error"] for dict in stats]

                    iters_plot = np.arange(1, len(rewards) + 1, 1)

                    ax1.plot(iterations, rewards, label=str(value))
                    # ax2.plot(changes, label=str(value))
                    ax3.plot(iterations, delta, label=str(value))

                    # rewards_list.append(rewards)

                ax3.set_yscale('log')
                ax1.legend(loc='lower right', fontsize=6, ncol=2)

                ax3.legend(loc='best', fontsize=6, ncol=2)
                path = os.path.join(self.output_dir)
                filename = title + ".png"
                filename = os.path.join(path, filename)
                plt.savefig(filename)
                plt.close()
        else:
            problem = self.problems[0]

            rewards_list = []
            hyper_params = problem[self.HYPER_PARAMS_INDEX]

            title = "Max Utility vs " + hyper_param_name + "\n" + self.problem_name + " Size " + problem[self.PROBLEM_SIZE_INDEX]
            title_dic = {'fontsize': 7, 'fontweight': 'bold'}
            fig, (ax1, ax3) = plt.subplots(1, 2, figsize=(6, 2))
            ax1.set_xlabel("Iterations", title_dic)
            #ax1.set_xscale('log')
            ax1.set_title(title , title_dic)
            ax1.set_ylabel("Max Utility", title_dic)
            ax1.tick_params(axis="x", labelsize=7)
            ax1.tick_params(axis="y", labelsize=7)
            ax1.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
            ax1.grid()

            title = "Change in Utility vs " + hyper_param_name + "\n" + self.problem_name + " Size " + problem[
                self.PROBLEM_SIZE_INDEX]

            ax3.set_xlabel("Iterations", title_dic)
            ax3.set_title(title, title_dic)
            ax3.set_ylabel("Delta Utility (Log)", title_dic)
            ax3.tick_params(axis="x", labelsize=7)
            ax3.tick_params(axis="y", labelsize=7)
            #ax3.set_ylim(top=.3, bottom=0.0)

            plt.tight_layout()
            plt.grid()

            if "n_iter" in hyper_params:
                iters = hyper_params["n_iter"]
            else:
                iters = 1000000

            if "epsilon" in hyper_params:
                epsilon = hyper_params["epsilon"]
            else:
                epsilon = 1

            if 'gamma' in hyper_params:
                gamma = hyper_params["gamma"]
            else:
                gamma = 0.99

            if 'alpha' in hyper_params:
                alpha = hyper_params["alpha"]
            else:
                alpha = 0.1

            if 'alpha_decay' in hyper_params:
                alpha_decay = hyper_params["alpha_decay"]
            else:
                alpha_decay = 0.99

            if 'epsilon_decay' in hyper_params:
                epsilon_decay = hyper_params["epsilon_decay"]
            else:
                epsilon_decay = 0.99

            for value in values:

                if hyper_param_name == 'gamma':
                    q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=value, alpha=alpha, alpha_decay=alpha_decay, epsilon=epsilon, n_iter=iters)
                elif hyper_param_name == 'max_iter':
                    q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, alpha=alpha, alpha_decay=alpha_decay, epsilon=epsilon, n_iter=value)
                elif hyper_param_name == 'epsilon':
                    q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, alpha=alpha, alpha_decay=alpha_decay, epsilon=value, n_iter=iters)
                elif hyper_param_name == 'alpha':
                    q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, alpha=value, alpha_decay=alpha_decay, epsilon=epsilon, n_iter=iters)
                elif hyper_param_name == 'alpha_decay':
                    q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, alpha=alpha, alpha_decay=value, epsilon=epsilon, n_iter=iters)
                elif hyper_param_name == 'epsilon_decay':
                    q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=gamma, alpha=alpha, alpha_decay=alpha_decay, epsilon=epsilon, epsilon_decay=value, n_iter=iters)

                stats = q.run()

                rewards = np.asarray([dict["Max V"] for dict in stats])
                iterations = [dict["Iteration"] for dict in stats]
                #changes = [dict["Changes In Policy"] for dict in stats]
                delta = [dict["Error"] for dict in stats]

                iters_plot = np.arange(1, len(rewards) + 1, 1)

                ax1.plot(iterations, rewards, label=str(value))
                #ax2.plot(changes, label=str(value))
                ax3.plot(iterations, delta, label=str(value))

                #rewards_list.append(rewards)

            ax3.set_yscale('log')
            ax1.legend(loc='lower right', fontsize=6, ncol=2)

            ax3.legend(loc='best', fontsize=6, ncol=2)
            path = os.path.join(self.output_dir)
            filename = title + ".png"
            filename = os.path.join(path, filename)
            plt.savefig(filename)
            plt.close()

    def plot_convergence(self):

        title = "Convergence for Q Learning \n" + self.problem_name
        title_dic = {'fontsize': 7, 'fontweight': 'bold'}
        fig, (ax3,ax1,ax2) = plt.subplots(1, 3, figsize=(9, 2.5))
        ax1.set_xlabel("Iterations", title_dic)
        ax1.set_title(title, title_dic)
        ax1.set_ylabel("Delta Utility", title_dic)
        ax1.tick_params(axis="x", labelsize=7)
        ax1.tick_params(axis="y", labelsize=7)
        ax1.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax1.grid()

        title1 = "Time (ms) vs Iterations \n" + self.problem_name
        ax2.set_xlabel("Iterations", title_dic)
        ax2.set_title(title1, title_dic)
        ax2.set_ylabel("Time(ms)", title_dic)
        ax2.tick_params(axis="x", labelsize=7)
        ax2.tick_params(axis="y", labelsize=7)
        ax2.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax2.grid()
        plt.tight_layout()
        plt.grid()

        title2 = "Max Utility vs Iterations \n" + self.problem_name
        ax3.set_xlabel("Iterations", title_dic)
        ax3.set_title(title2, title_dic)
        ax3.set_ylabel("Max Utility", title_dic)
        ax3.tick_params(axis="x", labelsize=7)
        ax3.tick_params(axis="y", labelsize=7)
        ax3.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax3.grid()
        plt.tight_layout()
        plt.grid()

        problem = self.problems[0]

        hyper_params = problem[self.HYPER_PARAMS_INDEX]
        q = QLearning(problem[self.P_INDEX], problem[self.R_INDEX], gamma=hyper_params['gamma'], alpha=hyper_params['alpha'], alpha_decay=hyper_params['alpha_decay'], epsilon=hyper_params['epsilon'], epsilon_decay=hyper_params['epsilon_decay'], n_iter=hyper_params['n_iter'])

        stats = q.run()
        time = [dict["Time"] for dict in stats]
        time = np.array(time)
        time = time * 1000
        print("Time to run q learning:" + str(time[-1]))
        time_delta = np.array([x - time[i - 1] for i, x in enumerate(time)][1:])
        time_delta = np.insert(time_delta,0,0)
        iterations = [dict["Iteration"] for dict in stats]

        maxV = [dict["Max V"] for dict in stats]
        print("Max utility q learning:" + str(maxV[-1]))

        self.policies[problem[self.PROBLEM_SIZE_INDEX]] = list(q.policy)
        self.times[problem[self.PROBLEM_SIZE_INDEX]] = time[-1]
        self.max_values[problem[self.PROBLEM_SIZE_INDEX]] = maxV

        path = os.path.join(self.output_dir)
        filename = "qrunstats"
        filename = os.path.join(path, filename)

        outfile = open(filename, 'wb')
        pickle.dump(stats, outfile)
        outfile.close()


        ax3.plot(iterations,maxV, label="Size:" + str(problem[self.PROBLEM_SIZE_INDEX]))

        delta = [dict["Error"] for dict in stats]
        ax1.plot(iterations,delta, label="Size:" + str(problem[self.PROBLEM_SIZE_INDEX]))

        ax2.plot(iterations,time_delta, label="Size:" + str(problem[self.PROBLEM_SIZE_INDEX]))

            #rewards_list.append(rewards)

        ax1.legend(loc='best', fontsize=6)
        ax2.legend(loc='best', fontsize=6)
        ax3.legend(loc='best', fontsize=6)
        path = os.path.join(self.output_dir)
        filename = title + ".png"
        filename = os.path.join(path, filename)
        plt.savefig(filename)
        plt.close()

    def plot_time_to_solution_for_varying_sizes(self):
        return



