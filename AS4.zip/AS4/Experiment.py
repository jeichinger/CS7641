import pandas as pd
import numpy as np
import os
import sys
import time as time
import gym
from CustomFrozenLakeEnv import CustomFrozenLakeEnv
from ValueIterationExperiment import ValueIterationExperiment
from PolicyIterationExperiment import PolicyIterationExperiment
from QLearningExperiment import QLearningExperiment
from hiive.mdptoolbox import example
import pickle
import PlottingUtils
LOG_PATH = os.getcwd() + "/Logs"

FROZEN_LAKE_PATH = os.getcwd() + "/Output/FrozenLake"
FOREST_PATH = os.getcwd() + "/Output/Forest"

def main(run_frozen_lake=True, run_forests=True, run_policy_iteration=True, run_value_iteration=True, run_q_learning=True):

    if run_frozen_lake:

        np.random.seed(1)
        frozen_lake_env_small = CustomFrozenLakeEnv(is_slippery=True, map_size=10, frozen_pct=0.70, finish_reward=10, hole_reward=-10, stochasticity_list=[0.2,0.6,0.2])
        frozen_lake_env_small.reset()
        frozen_lake_env_small.render()
        frozen_lake_env_large = CustomFrozenLakeEnv(is_slippery=True, map_size=50, frozen_pct=0.85, finish_reward=10, hole_reward=-10, stochasticity_list=[0.1,0.8,0.1])
        frozen_lake_env_large.reset()
        frozen_lake_env_large.render()

        problems = [(frozen_lake_env_small.mpd_tool_box_P, frozen_lake_env_small.mpd_tool_box_R, {"epsilon":0.0000001, "max_iter":10000}, "10x10"),
                    (frozen_lake_env_large.mpd_tool_box_P, frozen_lake_env_large.mpd_tool_box_R, {"epsilon":0.0000001, "max_iter":10000}, "50x50")]


        if run_value_iteration:

            frozen_lake_VI = ValueIterationExperiment(problems, FROZEN_LAKE_PATH + "/ValueIteration", "FrozenLake")

            frozen_lake_VI.tune_hyper_parameter('gamma', [.99,.95,.9,.8,.7,.6,.5,.4,.3,.2])

            # 0.99 was the best for both problem sizes.
            frozen_lake_VI.problems[0][2]['gamma'] = 0.99
            frozen_lake_VI.problems[0][2]['epsilon'] = 0.01

            frozen_lake_VI.problems[1][2]['gamma'] = 0.99
            frozen_lake_VI.problems[1][2]['epsilon'] = 0.001

            #frozen_lake_VI.tune_hyper_parameter('epsilon', [0.0001, 0.001, 0.01, 0.1, 0.5, 0.8, 1, 2])

            frozen_lake_VI.plot_convergence()

            policy = frozen_lake_VI.policies['10x10']
            frozen_lake_env_small.plot_policy("Value Iteration Policy", policy, (3,3))
            obs, reward, done, info = frozen_lake_env_small.step(policy[0])

            #frozen_lake_env_small.render()
            #while(not done) :
            #    obs, reward, done, info = frozen_lake_env_small.step(policy[obs])
            #    frozen_lake_env_small.render()

            policy = frozen_lake_VI.policies['50x50']
            frozen_lake_env_large.plot_policy("Value Iteration Policy", policy, (25,25))
            #obs, reward, done, info = frozen_lake_env_large.step(policy[0])
            #frozen_lake_env_large.render()
            #while(not done) :
            #    obs, reward, done, info = frozen_lake_env_large.step(policy[obs])
            #    frozen_lake_env_large.render()

        if run_policy_iteration:

            problems = [(frozen_lake_env_small.mpd_tool_box_P, frozen_lake_env_small.mpd_tool_box_R,
                         {"epsilon": 0.0000001, "max_iter": 10000}, "10x10"),
                        (frozen_lake_env_large.mpd_tool_box_P, frozen_lake_env_large.mpd_tool_box_R,
                         {"epsilon": 0.0000001, "max_iter": 10000}, "50x50")]

            frozen_lake_PI = PolicyIterationExperiment(problems, FROZEN_LAKE_PATH + "/PolicyIteration", "FrozenLake")

            frozen_lake_PI.tune_hyper_parameter('gamma', [.99,.95,.9,.8,.7,.6,.5,.4,.3,.2])

            # 0.99 was the best for both problem sizes.
            frozen_lake_PI.problems[0][2]['gamma'] = 0.99
            frozen_lake_PI.problems[1][2]['gamma'] = 0.99

            # frozen_lake_VI.tune_hyper_parameter('epsilon', [0.0001, 0.001, 0.01, 0.1, 0.5, 0.8, 1, 2])

            frozen_lake_PI.plot_convergence()

            policy = frozen_lake_PI.policies['10x10']
            frozen_lake_env_small.plot_policy("Policy Iteration Policy",policy, (3, 3))
            obs, reward, done, info = frozen_lake_env_small.step(policy[0])

            #frozen_lake_env_small.render()
            #while (not done):
            #    obs, reward, done, info = frozen_lake_env_small.step(policy[obs])
            #    frozen_lake_env_small.render()

            policy = frozen_lake_PI.policies['50x50']
            frozen_lake_env_large.plot_policy("Policy Iteration Policy",policy, (25, 25))
            obs, reward, done, info = frozen_lake_env_large.step(policy[0])
            #frozen_lake_env_large.render()
            #while (not done):
            #    obs, reward, done, info = frozen_lake_env_large.step(policy[obs])
            #    frozen_lake_env_large.render()

        if run_q_learning:
            print("Running q learning")

            problems = [(frozen_lake_env_small.mpd_tool_box_P, frozen_lake_env_small.mpd_tool_box_R,
                         {"epsilon": 1, "n_iter": 6000000}, "10x10"),
                        (frozen_lake_env_large.mpd_tool_box_P, frozen_lake_env_large.mpd_tool_box_R,
                         {"epsilon": 1, "n_iter": 10000000}, "50x50")]

            frozen_lake_q = QLearningExperiment(problems, FROZEN_LAKE_PATH + "/QLearning", "FrozenLake")

            frozen_lake_q.tune_hyper_parameter('gamma', [0.95, 0.90])

            frozen_lake_q.problems[0][2]['gamma'] = 0.99

            frozen_lake_q.tune_hyper_parameter('alpha', [0.05, 0.1, 0.2, 0.3, 0.4,0.5,0.6])
            frozen_lake_q.problems[0][2]['alpha'] = 0.1

            frozen_lake_q.tune_hyper_parameter('alpha_decay', [0.99, 0.90, 0.80, 0.70, 0.60,0.50])
            frozen_lake_q.problems[0][2]['alpha_decay'] = 0.6

            frozen_lake_q.tune_hyper_parameter('epsilon', [1, 0.95, 0.9, 0.80, 0.70,0.60,0.5])
            frozen_lake_q.problems[0][2]['epsilon'] = 1

            frozen_lake_q.tune_hyper_parameter('epsilon_decay', [0.99, 0.95, 0.9, 0.80, 0.70,0.60,0.5])
            frozen_lake_q.problems[0][2]['epsilon_decay'] = 0.99

            frozen_lake_q.plot_convergence()

            policy = frozen_lake_q.policies['10x10']
            frozen_lake_env_small.plot_policy("Q Learning Policy",policy, (3, 3))

    if run_forests:

        np.random.seed(1)

        forest_small_p, forest_small_r = example.forest(10)
        forest_large_p, forest_large_r = example.forest(1000)

        problems = [(forest_small_p, forest_small_r, {"epsilon":0.000000001, "max_iter":10000}, "10"),
                    (forest_large_p, forest_large_r, {"epsilon":0.000000001, "max_iter":10000}, "1000")]


        if run_value_iteration:

            frozen_lake_VI = ValueIterationExperiment(problems, FOREST_PATH + "/ValueIteration", "Forest")

            frozen_lake_VI.tune_hyper_parameter('gamma', [.99,.95,.9,.8,.7,.6,.5,.4,.3,.2])

            # 0.99 was the best for both problem sizes.
            frozen_lake_VI.problems[0][2]['gamma'] = 0.9
            #frozen_lake_VI.problems[0][2]['epsilon'] = 0.01

            frozen_lake_VI.problems[1][2]['gamma'] = 0.95
            frozen_lake_VI.problems[1][2]['epsilon'] = 0.1

            frozen_lake_VI.plot_convergence()

            policy = frozen_lake_VI.policies['10']
            PlottingUtils.plot_forest_policy(policy, "Value Iteration Policy \n Forest - Size 10")

            policy = frozen_lake_VI.policies['1000']
            PlottingUtils.plot_forest_policy(policy, "Value Iteration Policy \n Forest - Size 1000")

        if run_policy_iteration:

            problems = [(forest_small_p, forest_small_r, {"epsilon": 0.000000001, "max_iter": 10000}, "10"),
                        (forest_large_p, forest_large_r, {"epsilon": 0.000000001, "max_iter": 10000}, "1000")]

            frozen_lake_VI = PolicyIterationExperiment(problems, FOREST_PATH + "/PolicyIteration", "Forest")

            frozen_lake_VI.tune_hyper_parameter('gamma', [.99,.95,.9,.8,.7,.6,.5,.4,.3,.2])

            # 0.99 was the best for both problem sizes.
            frozen_lake_VI.problems[0][2]['gamma'] = 0.9
            #frozen_lake_VI.problems[0][2]['epsilon'] = 0.01

            frozen_lake_VI.problems[1][2]['gamma'] = 0.95

            frozen_lake_VI.plot_convergence()

            policy = frozen_lake_VI.policies['10']
            PlottingUtils.plot_forest_policy(policy, "Policy Iteration Policy \n Forest - Size 10")

            policy = frozen_lake_VI.policies['1000']
            PlottingUtils.plot_forest_policy(policy, "Policy Iteration Policy \n Forest - Size 1000")

        if run_q_learning:
            print("Running q learning")

            problems = [

                        (forest_large_p, forest_large_r,
                         {"epsilon": 1, "n_iter": 1000000}, "1000")]

            frozen_lake_q = QLearningExperiment(problems, FOREST_PATH + "/QLearning", "Forest")

            frozen_lake_q.tune_hyper_parameter('gamma', [0.99, 0.95, 0.90, 0.85])

            frozen_lake_q.problems[0][2]['gamma'] = 0.95

            frozen_lake_q.tune_hyper_parameter('alpha', [0.05, 0.1, 0.2, 0.3, 0.4,0.5,0.6])
            frozen_lake_q.problems[0][2]['alpha'] = 0.2
            #
            frozen_lake_q.tune_hyper_parameter('alpha_decay', [0.99, 0.90, 0.80, 0.70, 0.60,0.50])
            frozen_lake_q.problems[0][2]['alpha_decay'] = 0.8
            #
            frozen_lake_q.tune_hyper_parameter('epsilon', [1, 0.95, 0.9, 0.80, 0.70,0.60,0.5])
            frozen_lake_q.problems[0][2]['epsilon'] = .6
            #
            frozen_lake_q.tune_hyper_parameter('epsilon_decay', [0.99, 0.95, 0.9, 0.80, 0.70,0.60,0.5])
            frozen_lake_q.problems[0][2]['epsilon_decay'] = 0.99

            frozen_lake_q.plot_convergence()

            policy = frozen_lake_q.policies['1000']
            PlottingUtils.plot_forest_policy(policy, "Q Learning Policy \n Forest - Size 1000")


    #sys.stdout = open(os.path.join(LOG_PATH, 'log' + time.strftime("%Y%m%d-%H%M%S") + ".txt"), 'w+')

    sys.stdout.flush()
    sys.stdout.close()

if __name__ == "__main__":

    main()
