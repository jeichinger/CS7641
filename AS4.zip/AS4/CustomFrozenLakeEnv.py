'''
Code adpated from OpenAIGym frozen_lake.py
Supports generating random maps of specified size.
'''
import sys
from contextlib import closing

import numpy as np
from io import StringIO
import os
from gym import utils
from gym.envs.toy_text import discrete

import matplotlib.pyplot as plt

from matplotlib import colors

FROZEN_LAKE_PATH = os.getcwd() + "/Output/FrozenLake"
LEFT = 0
DOWN = 1
RIGHT = 2
UP = 3

MAPS = {
    "4x4": [
        "SFFF",
        "FHFH",
        "FFFH",
        "HFFG"
    ],
    "8x8": [
        "SFFFFFFF",
        "FFFFFFFF",
        "FFFHFFFF",
        "FFFFFHFF",
        "FFFHFFFF",
        "FHHFFFHF",
        "FHFFHFHF",
        "FFFHFFFG"
    ],
}


def generate_random_map(size=8, p=0.8):
    """Generates a random valid map (one that has a path from start to goal)
    :param size: size of each side of the grid
    :param p: probability that a tile is frozen
    """
    valid = False

    # DFS to check that it's a valid path.
    def is_valid(res):
        frontier, discovered = [], set()
        frontier.append((0, 0))
        while frontier:
            r, c = frontier.pop()
            if not (r, c) in discovered:
                discovered.add((r, c))
                directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]
                for x, y in directions:
                    r_new = r + x
                    c_new = c + y
                    if r_new < 0 or r_new >= size or c_new < 0 or c_new >= size:
                        continue
                    if res[r_new][c_new] == 'G':
                        return True
                    if (res[r_new][c_new] != 'H'):
                        frontier.append((r_new, c_new))
        return False

    while not valid:
        p = min(1, p)
        res = np.random.choice(['F', 'H'], (size, size), p=[p, 1-p])
        res[0][0] = 'S'
        res[-1][-1] = 'G'
        valid = is_valid(res)
    return ["".join(x) for x in res]


class CustomFrozenLakeEnv(discrete.DiscreteEnv):
    """
    Winter is here. You and your friends were tossing around a frisbee at the
    park when you made a wild throw that left the frisbee out in the middle of
    the lake. The water is mostly frozen, but there are a few holes where the
    ice has melted. If you step into one of those holes, you'll fall into the
    freezing water. At this time, there's an international frisbee shortage, so
    it's absolutely imperative that you navigate across the lake and retrieve
    the disc. However, the ice is slippery, so you won't always move in the
    direction you intend.
    The surface is described using a grid like the following
        SFFF
        FHFH
        FFFH
        HFFG
    S : starting point, safe
    F : frozen surface, safe
    H : hole, fall to your doom
    G : goal, where the frisbee is located
    The episode ends when you reach the goal or fall in a hole.
    You receive a reward of 1 if you reach the goal, and zero otherwise.
    """

    metadata = {'render.modes': ['human', 'ansi']}
    LEFT = 0
    DOWN = 1
    RIGHT = 2
    UP = 3

    def __init__(self, is_slippery=True, map_size=20, frozen_pct=0.8, step_reward=- 0.1, hole_reward=-1, finish_reward=1, stochasticity_list=[0.15, 0.70, 0.15]):

        desc = generate_random_map(map_size, frozen_pct)
        self.desc = desc = np.asarray(desc, dtype='c')
        self.nrow, self.ncol = nrow, ncol = desc.shape
        self.reward_range = (0, 1)
        self.stochasticity_list = stochasticity_list
        self.step_reward = step_reward
        self.hole_reward = hole_reward
        self.finish_reward = finish_reward

        self.mpd_tool_box_P = None
        self.mpd_tool_box_R = None

        nA = 4
        nS = nrow * ncol

        isd = np.array(desc == b'S').astype('float64').ravel()
        isd /= isd.sum()

        P = {s: {a: [] for a in range(nA)} for s in range(nS)}

        def to_s(row, col):
            return row*ncol + col

        def inc(row, col, a):
            if a == LEFT:
                col = max(col - 1, 0)
            elif a == DOWN:
                row = min(row + 1, nrow - 1)
            elif a == RIGHT:
                col = min(col + 1, ncol - 1)
            elif a == UP:
                row = max(row - 1, 0)
            return (row, col)

        def update_probability_matrix(row, col, action):
            newrow, newcol = inc(row, col, action)
            newstate = to_s(newrow, newcol)
            newletter = desc[newrow, newcol]
            done = bytes(newletter) in b'GH'

            if newletter == b'H':
                reward = self.hole_reward
            elif newletter == b'G':
                reward = self.finish_reward
            else:
                reward = self.step_reward

            #reward = float(newletter == b'G')
            return newstate, reward, done

        for row in range(nrow):
            for col in range(ncol):
                s = to_s(row, col)
                for a in range(4):
                    li = P[s][a]
                    letter = desc[row, col]
                    if letter in b'GH':
                        li.append((1.0, s, 0, True))
                    else:
                        if is_slippery:
                            index = 0
                            for b in [(a - 1) % 4, a, (a + 1) % 4]:
                                li.append((
                                    self.stochasticity_list[index],
                                    *update_probability_matrix(row, col, b)
                                ))
                                index += 1
                        else:
                            li.append((
                                1., *update_probability_matrix(row, col, a)
                            ))

        self.mpd_tool_box_P = np.zeros((4, nS, nS))
        self.mpd_tool_box_R = np.zeros((4, nS, nS))

        # convert to MDPToolbox support
        for i in range(len(P)):
            for j in range(4):

                data = P[i]
                movements = data[j]

                for movement in movements:
                    self.mpd_tool_box_P[j, i, movement[1]] += movement[0]
                    self.mpd_tool_box_R[j, i, movement[1]] += movement[2]

        print(np.sum(self.mpd_tool_box_P[0], axis=1))


        super(CustomFrozenLakeEnv, self).__init__(nS, nA, P, isd)

    def render(self, mode='human'):
        outfile = StringIO() if mode == 'ansi' else sys.stdout

        row, col = self.s // self.ncol, self.s % self.ncol
        desc = self.desc.tolist()
        desc = [[c.decode('utf-8') for c in line] for line in desc]

        desc[row][col] = utils.colorize(desc[row][col], "red", highlight=True)

        if self.lastaction is not None:
            outfile.write("  ({})\n".format(
                ["Left", "Down", "Right", "Up"][self.lastaction]))
        else:
            outfile.write("\n")
        outfile.write("\n".join(''.join(line) for line in desc)+"\n")

        if mode != 'human':
            with closing(outfile):
                return outfile.getvalue()

    def plot_policy(self, type, policy, figsize):

        map = self.unwrapped.desc
        #map = np.rot90(map)
        policy_reshaped = np.array(policy).reshape(map.shape[0], map.shape[1])
        #policy_reshaped = np.rot90(policy_reshaped)

        index_map = {b'H': 0, b'G': 1, b'S':2, b'F': 3}

        direction_map = {0: '⬅', 1: '⬇', 2: '➡', 3: '⬆'}

        cmap = colors.ListedColormap(['black', 'green', 'red', 'skyblue'])

        k = np.array(list(index_map.keys()))
        v = np.array(list(index_map.values()))

        out = np.zeros(map.shape)
        for key, val in zip(k, v):
            out[map == key] = val

        title = "Environment" + "\n" + 'Frozen Lake - Size: ' + str(map.shape[0]) + 'x' + str(map.shape[0])
        title_dic = {'fontsize': 7, 'fontweight': 'bold'}
        fig, (ax1) = plt.subplots(1, 1, figsize=figsize)
        ax1.set_title(title, title_dic)
        ax1.grid()

        ax1.invert_yaxis()

        ax1.pcolor(out, cmap=cmap, edgecolors='black')

        plt.axis('off')

        path = os.path.join(FROZEN_LAKE_PATH)
        filename = title + "Environment" + ".png"
        filename = os.path.join(path, filename)
        plt.savefig(filename)
        plt.close()

        cmap = colors.ListedColormap(['black', 'green', 'red', 'skyblue'])

        k = np.array(list(index_map.keys()))
        v = np.array(list(index_map.values()))

        out = np.zeros(map.shape)
        for key, val in zip(k, v):
            out[map == key] = val

        title = type + "\n" + 'Frozen Lake - Size: ' + str(map.shape[0]) + 'x' + str(map.shape[0])
        title_dic = {'fontsize': 7, 'fontweight': 'bold'}
        fig, (ax1) = plt.subplots(1, 1, figsize=figsize)
        ax1.set_title(title, title_dic)
        ax1.grid()

        ax1.invert_yaxis()

        ax1.pcolor(out, cmap=cmap, edgecolors='black')

        plt.axis('off')

        for y in range(map.shape[0]):
            for x in range(map.shape[1]):

                if x == map.shape[0] -1 and y == map.shape[1] -1:

                    plt.text(x + 0.5, y + 0.5, 'G',
                             horizontalalignment='center',
                             verticalalignment='center',
                             size=10
                             )
                else:

                    plt.text(x + 0.5, y + 0.5, direction_map[policy_reshaped[y,x]],
                             horizontalalignment='center',
                             verticalalignment='center',
                             size=10
                             )

        path = os.path.join(FROZEN_LAKE_PATH)
        filename = title + ".png"
        filename = os.path.join(path, filename)
        plt.savefig(filename)
        plt.close()