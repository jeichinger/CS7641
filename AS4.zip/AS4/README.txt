For Assignment 4 analysis I utilized OpenAIGym and hiive-mpdtoolbox.
The original datasets can be found at these links:

The zip file containing my code can be pulled from the following link: https://github.com/jeichinger/CS7641/blob/master/AS4.zip

To assist in running the experiment code, I've created a yml file located in the AS4 root directory. Simply create a virtual envirionment from the file, activate it, and run the Experiment.py file.

To remove the potential of OS issues making directories, I've included the empty ones in this repo. The directories are:
\Logs - Log files are written here
\Output - Output of experiments go here. The folder structure is as follows
	\FrozenLake
		\ValueIteration
		\PolicyIteration
		\QLearning
	\Forest
		\ValueIteration
		\PolicyIteration
		\QLearning

hiive-mpdtoolbo license:

Copyright (c) 2011-2013 Steven A. W. Cordwell
Copyright (c) 2009 INRA

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice, this
    list of conditions and the following disclaimer.
  * Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.
  * Neither the name of the <ORGANIZATION> nor the names of its contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


