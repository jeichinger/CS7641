from sklearn.cluster import KMeans
from matplotlib.ticker import FormatStrFormatter
import os
import numpy as np
import matplotlib.pyplot as plt
import time
import matplotlib.cm as cm
from sklearn.manifold import TSNE

LOG_PATH = os.getcwd() + "/Logs"
OUTPUT = os.getcwd() + "/Output"

SKIP_GRAPH_GEN = False
FOREST_PATH = os.getcwd() + "/Output/Forest"
def tune_hyper_parameter(k_range, X_train_transformed, title, outdir):

    if SKIP_GRAPH_GEN:
        return

    inertia_values = []
    silhouette_scores = []
    calinski_scores = []
    davies_score = []
    for k in k_range:
        kmeans = KMeans(n_clusters=k, max_iter=500)
        kmeans.fit_predict(X_train_transformed)
        inertia_values.append(kmeans.inertia_)
        silhouette_scores.append(silhouette_score(X_train_transformed, kmeans.labels_))
        calinski_scores.append(calinski_harabasz_score(X_train_transformed, kmeans.labels_))
        davies_score.append(davies_bouldin_score(X_train_transformed, kmeans.labels_))

    scaler = MinMaxScaler()
    inertia_values = scaler.fit_transform(np.asarray(inertia_values).reshape(-1, 1))
    silhouette_scores = scaler.fit_transform(np.asarray(silhouette_scores).reshape(-1, 1))
    calinski_scores = scaler.fit_transform(np.asarray(calinski_scores).reshape(-1, 1))
    davies_score = scaler.fit_transform(np.asarray(davies_score).reshape(-1, 1))

    title_dic = {'fontsize': 7, 'fontweight': 'bold'}

    fig, (ax1) = plt.subplots(1, 1, figsize=(5, 2))
    ax1.set_xlabel("K", title_dic)
    ax1.set_title(title, title_dic)
    ax1.set_ylabel("Normalized Score/Index", title_dic)
    ax1.tick_params(axis="x", labelsize=7)
    ax1.tick_params(axis="y", labelsize=7)
    ax1.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax1.plot(k_range, inertia_values, label="Inertia", linewidth=2)
    ax1.grid()

    ax1.plot(k_range, silhouette_scores, label="Silhouette Score", linewidth=2)
    ax1.plot(k_range, calinski_scores, label="Calinski-Harabasz Index", linewidth=2)
    ax1.plot(k_range, davies_score, label="Davies-Bouldin Index", linewidth=2)

    ax1.legend(loc='best', fontsize=6)

    plt.tight_layout()
    plt.grid()

    path = os.path.join(outdir)
    filename = title + ".png"
    filename = os.path.join(path, filename)
    plt.savefig(filename)
    plt.close()


def plot_forest_policy(policy, title):

    title_dic = {'fontsize': 7, 'fontweight': 'bold'}
    fig, (ax1) = plt.subplots(1, 1, figsize=(5, 3))
    ax1.set_xlabel("State", title_dic)
    ax1.set_title(title, title_dic)
    ax1.tick_params(axis="x", labelsize=7)
    plt.yticks([])

    cut = np.where(np.asarray(policy) == 1)[0]
    wait = np.where(np.asarray(policy) == 0)[0]

    bars = ax1.bar(cut, 0.5, color='blue', label='cut', width=1)
    bars2 = ax1.bar(wait, 0.5, color='green', label='wait', width=1)
    box = ax1.get_position()
    ax1.set_position([box.x0, box.y0, box.width * 0.8, box.height])

    # Put a legend to the right of the current axis
    ax1.legend(loc='center left', bbox_to_anchor=(1, 0.5))

    path = os.path.join(FOREST_PATH)
    filename = title + ".png"
    filename = os.path.join(path, filename)
    plt.savefig(filename)
    plt.close()
