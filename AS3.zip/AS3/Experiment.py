import pandas as pd
import numpy as np
import os
import DataPreprocessor
import PlottingUtils
import sys
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
from sklearn.metrics import homogeneity_completeness_v_measure
from sklearn.mixture import GaussianMixture
from sklearn.metrics import adjusted_mutual_info_score
from sklearn.decomposition import PCA
from sklearn.random_projection import GaussianRandomProjection
from sklearn.decomposition import KernelPCA
import NeuralNetworkModel
import time
import matplotlib.pyplot as plt

DATA_PATH = os.getcwd() + "/Data"
LOG_PATH = os.getcwd() + "/Logs"

def main(dataset2="diabetic.csv", dataset1="earthquake_processed.csv", run_part_1=True, run_part_2=True, run_part_3=True, run_part_4=True, run_part_5 = True, run_pca=True, run_ica=True, run_randomized_projection=True, run_kernel_pca=True, run_kmeans_nn=True, run_gmm_nn=True):

    sys.stdout = open(os.path.join(LOG_PATH, 'log' + time.strftime("%Y%m%d-%H%M%S") + ".txt"), 'w+')

    if dataset1 != "":

        print("Loading dataset " + dataset1, flush=True)

        # Load the data.
        dataset_csv_path = os.path.join(DATA_PATH, dataset1)
        dataset = pd.read_csv(dataset_csv_path)

        X = dataset.drop("class", axis=1)
        y = dataset["class"].copy()

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1)

        y_train = y_train.tolist()
        y_test = y_test.tolist()

        pipe = DataPreprocessor.preprocess_data(X_train)
        X_train_transformed = pipe.fit_transform(X_train)

        kmeans_model = None
        gmm_model = None

        if run_part_1:

            OUTPUT = os.getcwd() + "/Output/DRDataset/Part1"

            #PlottingUtils.generate_pair_plot("Feature Pair Plot - True Labels - DR Dataset", X_train_transformed,
            #                                np.array(y_train), columns=dataset.columns,
            #                                 x_labels=dataset.columns.tolist()[:-1],
            #                                 y_labels=dataset.columns.tolist()[:-1], outdir=OUTPUT)

            PlottingUtils.generate_pair_plot("Ground Truth Clusters DR - Dataset", X_train_transformed, y_train, 2, 5, outdir=OUTPUT)
            PlottingUtils.generate_pair_plot("Ground Truth Clusters DR - Dataset", X_train_transformed, y_train, 7, 4, outdir=OUTPUT)
            PlottingUtils.generate_pair_plot("Ground Truth Clusters DR - Dataset", X_train_transformed, y_train, 6, 2, outdir=OUTPUT)

            k_values = np.arange(2, 10, 1)
            PlottingUtils.plot_k_means_scores(k_values, X_train_transformed, "Normalized Scores of Various Metrics vs K - DR Dataset", outdir=OUTPUT)

            # By inspection, 3 was the best number of clusters.
            kmeans_model = KMeans(n_clusters=3, max_iter=500)

            start_time = time.time()
            kmeans_model.fit_predict(X_train_transformed)
            end_time = time.time()
            runtime = (end_time - start_time) * 1000

            print("Time to fit kmeans original: " + str(runtime) + "ms")

            homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, kmeans_model.labels_)
            print("Scores for DR Dataset")
            print("K Means")
            print("homogeneity:" + str(homogeneity))
            print("completeness:" + str(completeness))
            print("v measure:" + str(v_measure))
            print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, kmeans_model.labels_)))
            print()

            PlottingUtils.generate_pair_plot("KMeans Clusters DR - Dataset", X_train_transformed, kmeans_model.labels_, 2, 5, outdir=OUTPUT)
            PlottingUtils.generate_pair_plot("KMeans Clusters DR - Dataset", X_train_transformed, kmeans_model.labels_, 7, 4, outdir=OUTPUT)
            PlottingUtils.generate_pair_plot("KMeans Clusters DR - Dataset", X_train_transformed, kmeans_model.labels_, 6, 2, outdir=OUTPUT)

            k_values = np.arange(2, 15, 1)
            PlottingUtils.plot_gmm_scores(k_values, X_train_transformed, "EM - DR Dataset", outdir=OUTPUT)

            # By inspection, 4 clusters were best.
            gmm_model = GaussianMixture(4, max_iter=500, n_init=10, random_state=1)

            start_time = time.time()
            gmm_model.fit(X_train_transformed)
            end_time = time.time()
            runtime = (end_time - start_time) * 1000

            print("Time to fit em original: " + str(runtime) + "ms")

            labels = np.array(gmm_model.predict(X_train_transformed))

            homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, labels)
            print("EM")
            print("homogeneity:" + str(homogeneity))
            print("completeness:" + str(completeness))
            print("v measure:" + str(v_measure))
            print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, labels)))
            print()

            PlottingUtils.generate_pair_plot("EM Clusters DR - Dataset", X_train_transformed, labels, 2, 5, outdir=OUTPUT)
            PlottingUtils.generate_pair_plot("EM Clusters DR - Dataset", X_train_transformed, labels, 7, 4, outdir=OUTPUT)
            PlottingUtils.generate_pair_plot("EM Clusters DR - Dataset", X_train_transformed, labels, 6, 2, outdir=OUTPUT)

        pca_reduced_features = None
        pca_reducer = None
        ica_reduced_features = None
        ica_reducer = None
        ica_components = None
        rp_reduced_features = None
        rp_reducer = None
        kernel_pca_reduced_features = None
        kernel_pca_reducer = None

        if run_part_2:

            OUTPUT = os.getcwd() + "/Output/DRDataset/Part2"

            if run_pca:
                # PCA
                PlottingUtils.generate_pca("PCA Explained Variance vs # of Components \n DR Dataset","PCA Sorted Eigen Values for each Eigen Vector \n DR Dataset", X_train_transformed, 19, outdir=OUTPUT)

                # Best number of components was 8 for PCA
                pca_reducer = PCA(n_components=8)

                start_time = time.time()
                pca_reduced_features = pca_reducer.fit_transform(X_train_transformed)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000

                print("Time to fit PCA: " + str(runtime) + "ms")


                column_names = ["PC1" , "PC2", "PC3", "PC4", "PC5", "PC6", "PC7", "PC8", "class"]

                PlottingUtils.generate_pair_plot("PCA Clusters DR - Dataset", pca_reduced_features,
                                                 y_train, 1, 0, outdir=OUTPUT)
            if run_ica:
                ica_reduced_features, ica_reducer, ica_components = PlottingUtils.generate_ica("Average Kurtosis vs # of Components \n DR Dataset", "Kurtosis of each component for 16 Components \n DR Dataset", X_train_transformed, np.arange(1,20,1),OUTPUT, 16, [2, 4, 6, 11, 14, 15])
                column_names = ["ICA Comp 2", "ICA Comp 4", "ICA Comp 6", "ICA Comp 11", "ICA Comp 14", "ICA Comp 15", "class"]

                PlottingUtils.generate_pair_plot("ICA Clusters DR - Dataset", ica_reduced_features,
                                                 y_train, 4, 1, outdir=OUTPUT)

            if run_randomized_projection:

                PlottingUtils.generate_random_projection("Randomized Projection # of Components vs \n Reconstruction MSE over 10 runs", X_train_transformed, np.arange(1,20,1), outdir=OUTPUT)

                rp_reducer = GaussianRandomProjection(n_components=10, random_state=1)

                start_time = time.time()
                rp_reduced_features = rp_reducer.fit_transform(X_train_transformed)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000

                print("Time to fit RP: " + str(runtime) + "ms")

                column_names = ["Rand Proj 1", "Rand Proj 2", "Rand Proj 3", "Rand Proj 4", "Rand Proj 5", "Rand Proj 6", "Rand Proj 7", "Rand Proj 8", "Rand Proj 9", "Rand Proj 10",  "class"]

                PlottingUtils.generate_pair_plot("RP Clusters DR - Dataset", rp_reduced_features,
                                                 y_train, 4, 0, outdir=OUTPUT)
            if run_kernel_pca:

                PlottingUtils.generate_kernel_pca("Kernel PCA # of Components vs Explained Variance \n DR Dataset", "Principal Components Poly Degree 3 Kernel \n Earthquake Dataset",X_train_transformed, np.arange(2,20,1), outdir=OUTPUT)

                kernel_pca_reducer = KernelPCA(n_components=3, kernel='poly', fit_inverse_transform=True, degree=3)

                start_time = time.time()
                kernel_pca_reduced_features = kernel_pca_reducer.fit_transform(X_train_transformed)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit Kernel PCA: " + str(runtime) + "ms")

                column_names = ["PCA 1", "PCA 2", "PCA 3", "class"]

                PlottingUtils.generate_pair_plot("Kernel PCA Clusters DR - Dataset", kernel_pca_reduced_features,
                                                 y_train, 0, 2, outdir=OUTPUT)

                PlottingUtils.generate_pair_plot("Kernel PCA Clusters DR - Dataset", kernel_pca_reduced_features,
                                                 y_train, 2, 2, outdir=OUTPUT)

        if run_part_3:

            OUTPUT = os.getcwd() + "/Output/DRDataset/Part3"

            if run_pca:

                k_values = np.arange(2, 10, 1)
                PlottingUtils.plot_k_means_scores(k_values, pca_reduced_features, "Normalized Scores of Various Metrics vs K - PCA Reduced Features \n DR Dataset", outdir=OUTPUT)

                # By inspection, 3 was the best number of clusters.
                kmeans = KMeans(n_clusters=3, max_iter=500)

                start_time = time.time()
                kmeans.fit_predict(pca_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit kmeans PCA: " + str(runtime) + "ms")

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, kmeans.labels_)
                print("Scores for DR Dataset - PCA Reduced")
                print("K Means")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, kmeans.labels_)))
                print()

                k_values = np.arange(2, 15, 1)
                PlottingUtils.plot_gmm_scores(k_values, pca_reduced_features, "EM - PCA Reduced Features \nDR Dataset", outdir=OUTPUT)

                # By inspection, 4 clusters were best.
                gmm = GaussianMixture(9, max_iter=500, n_init=10)

                start_time = time.time()
                gmm.fit(pca_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit em PCA: " + str(runtime) + "ms")

                labels = np.array(gmm.predict(pca_reduced_features))

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, labels)
                print("EM")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, labels)))
                print()

                #PlottingUtils.generate_pair_plot("Feature Pair Plot - EM - PCA Reduced - DR Dataset", pca_reduced_features, labels, columns=column_names, x_labels=column_names[:-1],
                #                                 y_labels=column_names[:-1], outdir=OUTPUT)

            if run_ica:

                k_values = np.arange(2, 10, 1)
                PlottingUtils.plot_k_means_scores(k_values, ica_reduced_features, "Normalized Scores of Various Metrics vs K - ICA Reduced Features \n DR Dataset", outdir=OUTPUT)

                # By inspection, 3 was the best number of clusters.
                kmeans = KMeans(n_clusters=3, max_iter=500)
                start_time = time.time()
                kmeans.fit_predict(ica_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit kmeans ICA: " + str(runtime) + "ms")

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, kmeans.labels_)
                print("Scores for DR Dataset - ICA Reduced")
                print("K Means")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, kmeans.labels_)))
                print()

                column_names = ["1", "2", "3", "4", "5", "6", "class"]

                #PlottingUtils.generate_pair_plot("Feature Pair Plot - KMeans - ICA Reduced Features \n - DR Dataset", ica_reduced_features, kmeans.labels_, columns=column_names,x_labels=column_names[:-1],
                #                                 y_labels=column_names[:-1], outdir=OUTPUT)

                k_values = np.arange(2, 15, 1)
                PlottingUtils.plot_gmm_scores(k_values, ica_reduced_features, "EM - ICA Reduced Features \nDR Dataset", outdir=OUTPUT)

                # By inspection, 3 clusters were best.
                gmm = GaussianMixture(3, max_iter=500, n_init=10)
                start_time = time.time()
                gmm.fit(ica_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit em ICA: " + str(runtime) + "ms")

                labels = np.array(gmm.predict(ica_reduced_features))

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, labels)
                print("EM")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, labels)))
                print()

                #PlottingUtils.generate_pair_plot("Feature Pair Plot - EM - ICA Reduced - DR Dataset", ica_reduced_features, labels, columns=column_names, x_labels=column_names[:-1],
                #                                 y_labels=column_names[:-1], outdir=OUTPUT)

            if run_randomized_projection:

                k_values = np.arange(2, 10, 1)
                PlottingUtils.plot_k_means_scores(k_values, rp_reduced_features, "Normalized Scores of Various Metrics vs K - RP Reduced Features \n DR Dataset", outdir=OUTPUT)

                # By inspection, 3 was the best number of clusters.
                kmeans = KMeans(n_clusters=6, max_iter=500)
                start_time = time.time()
                kmeans.fit_predict(rp_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit kmeans random projection: " + str(runtime) + "ms")

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, kmeans.labels_)
                print("Scores for DR Dataset - RP Reduced")
                print("K Means")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, kmeans.labels_)))
                print()

                column_names = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "class"]

                #PlottingUtils.generate_pair_plot("Feature Pair Plot - KMeans - RP Reduced Features \n - DR Dataset", rp_reduced_features, kmeans.labels_, columns=column_names,x_labels=column_names[:-1],
                #                                 y_labels=column_names[:-1], outdir=OUTPUT)

                k_values = np.arange(2, 15, 1)
                PlottingUtils.plot_gmm_scores(k_values, rp_reduced_features, "EM - RP Reduced Features \nDR Dataset", outdir=OUTPUT)

                # By inspection, 3 clusters were best.
                gmm = GaussianMixture(5, max_iter=500, n_init=10)
                start_time = time.time()
                gmm.fit(rp_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit EM randomized projection: " + str(runtime) + "ms")

                labels = np.array(gmm.predict(rp_reduced_features))

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, labels)
                print("EM")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, labels)))
                print()

                #PlottingUtils.generate_pair_plot("Feature Pair Plot - EM - RP Reduced - DR Dataset", rp_reduced_features, labels, columns=column_names, x_labels=column_names[:-1],
                #                                 y_labels=column_names[:-1], outdir=OUTPUT)

            if run_kernel_pca:

                k_values = np.arange(2, 10, 1)
                PlottingUtils.plot_k_means_scores(k_values, kernel_pca_reduced_features, "Normalized Scores of Various Metrics vs K - Kernel PCA Reduced Features \n DR Dataset", outdir=OUTPUT)

                # By inspection, 3 was the best number of clusters.
                kmeans = KMeans(n_clusters=3, max_iter=500)
                start_time = time.time()
                kmeans.fit_predict(kernel_pca_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit kmeans kernel PCA: " + str(runtime) + "ms")

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, kmeans.labels_)
                print("Scores for DR Dataset - Kernel PCA Reduced")
                print("K Means")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, kmeans.labels_)))
                print()

                column_names = ["1", "2", "3", "class"]

                #PlottingUtils.generate_pair_plot("Feature Pair Plot - KMeans - Kernel PCA Reduced Features \n - DR Dataset", kernel_pca_reduced_features, kmeans.labels_, columns=column_names,x_labels=column_names[:-1],
                #                                 y_labels=column_names[:-1], outdir=OUTPUT)

                k_values = np.arange(2, 15, 1)
                PlottingUtils.plot_gmm_scores(k_values, kernel_pca_reduced_features, "EM - Kernel PCA Reduced Features \nDR Dataset", outdir=OUTPUT)

                # By inspection, 3 clusters were best.
                gmm = GaussianMixture(3, max_iter=500, n_init=10)
                start_time = time.time()
                gmm.fit(kernel_pca_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit em kernel PCA: " + str(runtime) + "ms")

                labels = np.array(gmm.predict(kernel_pca_reduced_features))

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, labels)
                print("EM")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, labels)))
                print()

                #PlottingUtils.generate_pair_plot("Feature Pair Plot - EM - Kernel PCA Reduced - DR Dataset", kernel_pca_reduced_features, labels, columns=column_names, x_labels=column_names[:-1],
                #                                y_labels=column_names[:-1], outdir=OUTPUT)

        OUTPUT = os.getcwd() + "/Output/DRDataset/Part4"

        print("running nn experiment")
        ann = NeuralNetworkModel.NeuralNetworkModel(X_train_transformed, X_test, y_train, y_test, pipe, None,["No DR", "DR"],
                                 "DR", OUTPUT, "Normal")

        # Params taken from AS!
        ann.model_params['solver'] = 'sgd'
        ann.model_params['max_iter'] = 1000
        ann.model_params['learning_rate_init'] = 0.004
        ann.model_params['hidden_layer_sizes'] = (12)
        ann.model_params['learning_rate_init'] = 0.006
        ann.model_params['hidden_layer_sizes'] = (12, 2)
        ann.model_params['tol'] = 0.000001
        ann.update_and_refit_model()
        normal_loss_curve = ann.plot_epochs_vs_iterations()
        normal_nn_score = ann.run_cross_val_on_test_set("Neural Network")
        normal_nn_train_times, normal_nn_test_times, _ = ann.generate_learning_curves("Final CV Learning Curve - No Reduction",
                                                                                          "Artificial Neural Network")
        if run_part_4:

            if run_pca:
                nn = NeuralNetworkModel.NeuralNetworkModel(pca_reduced_features, X_test, y_train, y_test, pipe,
                                                           pca_reducer, ["No DR", "DR"], "DR", OUTPUT,
                                                           "PCA")

                nn.model_params['solver'] = 'sgd'
                #nn.update_and_refit_model()
                #nn.generate_learning_curves("CV Learning Curve Before Any Tuning", "Artificial Neural Network")

                print("Finding optimal learning rate")
                param_range = [0.0001, 0.001, 0.01, 0.1]
                #nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network")

                #nn.model_params['learning_rate_init'] = 0.01
                #nn.update_and_refit_model()

                print("Finding optimal hidden layers")
                param_range = [(2), (3), (4), (5), (6), (7), (8), (9), (10), (11), (12), (13), (14), (15)]
                #nn.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 1)

                nn.model_params['hidden_layer_sizes'] = (14)
                #nn.update_and_refit_model()

                print("Finding optimal learning rate")
                param_range = [0.0005,0.001,0.003,0.005, 0.007]
                #nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 2)

                # pca_nn.generate_learning_curves("CV Learning Curve After Tuning Initial Learning Rate",
                #                             "Artificial Neural Network")

                nn.model_params['learning_rate_init'] = 0.005
                #nn.update_and_refit_model()

                #nn.generate_learning_curves("CV Learning Curve After Tuning 1st Hidden Layer", "Artificial Neural Network")

                #print("Finding optimal momentum rate")
                param_range = [0.80, 0.84, 0.86, 0.88, 0.9, 0.92, 0.94]
                #nn.tune_hyper_parameter('momentum', param_range, "Artificial Neural Network", 1)

                #nn.model_params['momentum'] = 0.90
                # ica_nn.update_and_refit_model()

                #print("Finding optimal hidden layers")
                param_range = [14, (14, 2), (14, 4), (14, 6), (14, 8)]
                #nn.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 2)

                # nn.model_params['hidden_layer_sizes'] = (13, 2)
                # nn.update_and_refit_model()

                # nn.generate_learning_curves("CV Learning Curve After Tuning 2nd Hidden Layer", "Artificial Neural Network")

                # print("Finding optimal learning rate")
                param_range = [0.015, 0.02, 0.025, 0.04, 0.06, 0.07, 0.08, 0.09, 0.10, 0.12, 0.14]
                # ica_nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 3)

                # ica_nn.model_params['learning_rate_init'] = 0.025
                # ica_nn.update_and_refit_model()

                nn.model_params['tol'] = 0.000001
                #nn.update_and_refit_model()

                #nn.tune_hyper_parameter('max_iter', np.arange(100, 1000, 100), "PCA")

                nn.model_params['max_iter'] = 225
                pca_loss_curve = nn.plot_epochs_vs_iterations()

                pca_nn_score = nn.run_cross_val_on_test_set("Neural Network")

                pca_nn_train_times, pca_nn_test_times, _ = nn.generate_learning_curves(
                    "Final CV Learning Curve - PCA",
                    "Artificial Neural Network")
            if run_ica:

                nn = NeuralNetworkModel.NeuralNetworkModel(ica_reduced_features, X_test, y_train, y_test, pipe,
                                                           ica_reducer, ["No DR", "DR"], "DR", OUTPUT,
                                                           "ICA", ica_components=ica_components)

                nn.model_params['solver'] = 'sgd'
                #nn.update_and_refit_model()
                #nn.generate_learning_curves("CV Learning Curve Before Any Tuning", "Artificial Neural Network")

                print("Finding optimal learning rate")
                param_range = [0.0001, 0.001, 0.01, 0.1]
                #nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network")

                #nn.model_params['learning_rate_init'] = 0.01
                #nn.update_and_refit_model()

                print("Finding optimal hidden layers")
                param_range = [(3), (4), (5), (6), (7), (8), (9), (10), (11), (12), (13), (14), (15), (100)]
                #nn.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 1)

                nn.model_params['hidden_layer_sizes'] = (6)
                #nn.update_and_refit_model()

                print("Finding optimal learning rate")
                param_range = [0.001, 0.010, 0.1]
                #nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 2)

                # pca_nn.generate_learning_curves("CV Learning Curve After Tuning Initial Learning Rate",
                #                             "Artificial Neural Network")

                nn.model_params['learning_rate_init'] = 0.0010
                #nn.update_and_refit_model()

                #nn.generate_learning_curves("CV Learning Curve After Tuning 1st Hidden Layer", "Artificial Neural Network")

                print("Finding optimal momentum rate")
                param_range = [0.50,0.60,0.70,0.80, 0.90, 0.92]
                #nn.tune_hyper_parameter('momentum', param_range, "Artificial Neural Network", 1)

                #nn.model_params['momentum'] = 0.90
                #nn.update_and_refit_model()

                print("Finding optimal hidden layers")
                param_range = [5, (5, 2), (5, 4)]
                #nn.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 2)

                #nn.model_params['hidden_layer_sizes'] = (13, 2)
                # nn.update_and_refit_model()

                # nn.generate_learning_curves("CV Learning Curve After Tuning 2nd Hidden Layer", "Artificial Neural Network")

                # print("Finding optimal learning rate")
                param_range = [0.015, 0.02, 0.025, 0.04, 0.06, 0.07, 0.08, 0.09, 0.10, 0.12, 0.14]
                # ica_nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 3)

                # ica_nn.model_params['learning_rate_init'] = 0.025
                # ica_nn.update_and_refit_model()

                nn.model_params['tol'] = 0.000001

                #nn.tune_hyper_parameter('max_iter', np.arange(100, 4000, 500), "ICA")

                nn.model_params['max_iter'] = 400
                ica_loss_curve = nn.plot_epochs_vs_iterations()

                ica_nn_score = nn.run_cross_val_on_test_set("Neural Network")

                ica_nn_train_times, ica_nn_test_times, _ = nn.generate_learning_curves(
                    "Final CV Learning Curve - ICA",
                    "Artificial Neural Network")

            if run_randomized_projection:

                nn = NeuralNetworkModel.NeuralNetworkModel(rp_reduced_features, X_test, y_train, y_test, pipe,
                                                               rp_reducer, ["No DR", "DR"], "DR", OUTPUT, "Randomized Projection")

                nn.model_params['solver'] = 'sgd'

                #ica_nn.generate_learning_curves("CV Learning Curve Before Any Tuning", "Artificial Neural Network")

                #nn.model_params['max_iter'] = 5000
                #nn.model_params['n_iter_no_change'] = 150

                # pca_nn.model_params['early_stopping'] = True
                # pca_nn.update_and_refit_model()

                print("Finding optimal learning rate")
                param_range = [0.003,0.004, 0.005, 0.006, 0.007, 0.008, 0.009]
                #nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network")

                nn.model_params['learning_rate_init'] = 0.005
                #nn.update_and_refit_model()

                print("Finding optimal hidden layers")
                param_range = [(2), (3), (4), (5), (6), (7), (8), (9), (10), (11), (12), (13), (14), (15)]
                #nn.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 1)

                nn.model_params['hidden_layer_sizes'] = (13)
                #nn.update_and_refit_model()

                print("Finding optimal learning rate")
                param_range = [0.005, 0.007, 0.008, 0.009, 0.010, 0.015, 0.020]
                #nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 2)

                # pca_nn.generate_learning_curves("CV Learning Curve After Tuning Initial Learning Rate",
                #                             "Artificial Neural Network")

                nn.model_params['learning_rate_init'] = 0.009
                #nn.update_and_refit_model()

                #nn.generate_learning_curves("CV Learning Curve After Tuning 1st Hidden Layer", "Artificial Neural Network")

                print("Finding optimal momentum rate")
                param_range = [0.80, 0.84, 0.86, 0.88, 0.9, 0.92, 0.94]
                #nn.tune_hyper_parameter('momentum', param_range, "Artificial Neural Network", 1)

                nn.model_params['momentum'] = 0.90
                #ica_nn.update_and_refit_model()

                print("Finding optimal hidden layers")
                param_range = [13, (13, 2), (13, 3), (13, 4), (13, 6)]
                #nn.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 2)

                #nn.model_params['hidden_layer_sizes'] = (13, 2)
                #nn.update_and_refit_model()

                #nn.generate_learning_curves("CV Learning Curve After Tuning 2nd Hidden Layer", "Artificial Neural Network")

                #print("Finding optimal learning rate")
                param_range = [0.015, 0.02, 0.025, 0.04, 0.06, 0.07, 0.08, 0.09, 0.10, 0.12, 0.14]
                #ica_nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 3)

                #ica_nn.model_params['learning_rate_init'] = 0.025
                #ica_nn.update_and_refit_model()

                nn.model_params['tol'] = 0.000001
                #nn.update_and_refit_model()

                #nn.tune_hyper_parameter('max_iter', np.arange(100, 1000, 100), "Randomized Projection")

                nn.model_params['max_iter'] = 225
                rp_loss_curve = nn.plot_epochs_vs_iterations()

                rp_nn_score = nn.run_cross_val_on_test_set("Neural Network")

                rp_nn_train_times, rp_nn_test_times, _ = nn.generate_learning_curves(
                    "Final CV Learning Curve - Randomized Projection",
                    "Artificial Neural Network")

            if run_kernel_pca:

                nn = NeuralNetworkModel.NeuralNetworkModel(kernel_pca_reduced_features, X_test, y_train, y_test, pipe,
                                                               kernel_pca_reducer, ["No DR", "DR"], "DR", OUTPUT, "Kernel PCA")

                nn.model_params['solver'] = 'sgd'
                nn.update_and_refit_model()
                #nn.generate_learning_curves("CV Learning Curve Before Any Tuning", "Artificial Neural Network")

                print("Finding optimal learning rate")
                param_range = [0.0001,0.001, 0.01, 0.1]
                #nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network")

                nn.model_params['learning_rate_init'] = 0.01
                nn.update_and_refit_model()

                print("Finding optimal hidden layers")
                param_range = [(2), (3), (4), (5), (6), (7), (8), (9), (10), (11), (12), (13), (14), (15)]
                #nn.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 1)

                nn.model_params['hidden_layer_sizes'] = (7)
                #nn.update_and_refit_model()

                print("Finding optimal learning rate")
                param_range = [0.005, 0.007, 0.008, 0.009, 0.010, 0.011, 0.0125]
                #nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 2)

                # pca_nn.generate_learning_curves("CV Learning Curve After Tuning Initial Learning Rate",
                #                             "Artificial Neural Network")

                nn.model_params['learning_rate_init'] = 0.010
                #nn.update_and_refit_model()

                #nn.generate_learning_curves("CV Learning Curve After Tuning 1st Hidden Layer", "Artificial Neural Network")

                print("Finding optimal momentum rate")
                param_range = [0.80, 0.84, 0.86, 0.88, 0.9, 0.92, 0.94]
                #nn.tune_hyper_parameter('momentum', param_range, "Artificial Neural Network", 1)

                nn.model_params['momentum'] = 0.90
                #ica_nn.update_and_refit_model()

                print("Finding optimal hidden layers")
                param_range = [7, (7, 2), (7, 3), (7, 4), (7, 6)]
                #nn.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 2)

                #nn.model_params['hidden_layer_sizes'] = (13, 2)
                #nn.update_and_refit_model()

                #nn.generate_learning_curves("CV Learning Curve After Tuning 2nd Hidden Layer", "Artificial Neural Network")

                #print("Finding optimal learning rate")
                param_range = [0.015, 0.02, 0.025, 0.04, 0.06, 0.07, 0.08, 0.09, 0.10, 0.12, 0.14]
                #ica_nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 3)

                #ica_nn.model_params['learning_rate_init'] = 0.025
                #ica_nn.update_and_refit_model()

                nn.model_params['tol'] = 0.000001
                #nn.update_and_refit_model()

                #nn.tune_hyper_parameter('max_iter', np.arange(100, 5000, 500), "K PCA")

                nn.model_params['max_iter'] = 400

                kpca_loss_curve = nn.plot_epochs_vs_iterations()

                kpca_nn_score = nn.run_cross_val_on_test_set("Neural Network")

                kpca_nn_train_times, kpca_nn_test_times, _ = nn.generate_learning_curves(
                    "Final CV Learning Curve - Randomized Projection",
                    "Artificial Neural Network")

            title_dic = {'fontsize': 7, 'fontweight': 'bold'}
            axis_label_size = 7

            fig, (fitness_cp, time_cp) = plt.subplots(1, 2, figsize=(6.5, 2))
            fitness_cp.set_title(
                "Loss vs Iterations \n NN Tuning", title_dic)
            fitness_cp.set_ylabel("Loss", title_dic)
            fitness_cp.tick_params(axis="x", labelsize=axis_label_size)
            fitness_cp.tick_params(axis="y", labelsize=axis_label_size)
            fitness_cp.set_xlabel("Iteration", title_dic)

            fitness_cp.set_ylim(top=1, bottom=0.3)

            fitness_cp.plot(normal_loss_curve, label="No\nReduction")
            fitness_cp.plot(pca_loss_curve, label="PCA")
            fitness_cp.plot(rp_loss_curve, label="RP")
            fitness_cp.plot(ica_loss_curve, label="ICA")
            fitness_cp.plot(kpca_loss_curve, label="Kernel\nPCA")

            fitness_cp.legend(loc='upper right', ncol=1, fontsize=5.5)

            time_cp.set_xlabel("Time (s)", title_dic)
            time_cp.set_title("Runtime For Training", title_dic)
            time_cp.set_ylabel("Algorithm", title_dic)
            time_cp.tick_params(axis="x", labelsize=axis_label_size)
            time_cp.tick_params(axis="y", labelsize=axis_label_size)

            x = ['No Reduction', 'PCA', 'ICA', 'RP', 'Kernel PCA']
            x_pos = [i for i, _ in enumerate(x)]
            time_cp.set_yticks(x_pos)
            time_cp.set_yticklabels(x)
            time_cp.barh(x_pos, [normal_nn_train_times[-1], pca_nn_train_times[-1], ica_nn_train_times[-1], rp_nn_train_times[-1], kpca_nn_train_times[-1] ])

            print("Normal F1 Score: " + str(normal_nn_score))
            print("PCA F1 Score: " + str(pca_nn_score))
            print("ICA F1 Score: " + str(ica_nn_score))
            print("RP F1 Score: " + str(rp_nn_score))
            print("Kernel PCA F1 Score: " + str(kpca_nn_score))

            time_cp.grid()
            fitness_cp.grid()
            plt.tight_layout()

            path = OUTPUT
            filename = "loss_vs_iteration.png"
            filename = os.path.join(path, filename)
            plt.savefig(filename)

        if run_part_5:

            OUTPUT = os.getcwd() + "/Output/DRDataset/Part5"

            if run_kmeans_nn:

                # Features are distances to each cluster
                x_reduced = kmeans_model.transform(X_train_transformed)

                nn = NeuralNetworkModel.NeuralNetworkModel(x_reduced, X_test, y_train, y_test, pipe,
                                                           None, ["No DR", "DR"], "DR", OUTPUT,
                                                           "KMeans", kmeans_model = kmeans_model)
                # nn.update_and_refit_model()
                # nn.generate_learning_curves("CV Learning Curve Before Any Tuning", "Artificial Neural Network")

                print("Finding optimal hidden layers")
                param_range = [(3), (4), (5), (6), (7), (8), (9), (10), (11), (12), (13), (14), (15), (100)]
                #nn.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 1)

                nn.model_params['hidden_layer_sizes'] = (3)
                nn.update_and_refit_model()

                print("Finding optimal learning rate")
                param_range = [0.001, 0.010, 0.1, 0.2, 0.3, 0.4 ,0.5, 0.6, 0.7]
                #nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 2)

                # pca_nn.generate_learning_curves("CV Learning Curve After Tuning Initial Learning Rate",
                #                             "Artificial Neural Network")

                nn.model_params['learning_rate_init'] = 0.6
                # nn.update_and_refit_model()

                #nn.generate_learning_curves("CV Learning Curve After Tuning 1st Hidden Layer", "Artificial Neural Network")

                print("Finding optimal momentum rate")
                param_range = [0.50, 0.60, 0.70, 0.80, 0.90, 0.92]
                #nn.tune_hyper_parameter('momentum', param_range, "Artificial Neural Network", 1)

                # nn.model_params['momentum'] = 0.90
                # nn.update_and_refit_model()

                print("Finding optimal hidden layers")
                param_range = [5, (5, 2), (5, 4)]
                # nn.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 2)

                # nn.model_params['hidden_layer_sizes'] = (13, 2)
                # nn.update_and_refit_model()

                # nn.generate_learning_curves("CV Learning Curve After Tuning 2nd Hidden Layer", "Artificial Neural Network")

                # print("Finding optimal learning rate")
                param_range = [0.015, 0.02, 0.025, 0.04, 0.06, 0.07, 0.08, 0.09, 0.10, 0.12, 0.14]
                # ica_nn.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 3)

                # ica_nn.model_params['learning_rate_init'] = 0.025
                # ica_nn.update_and_refit_model()

                nn.model_params['tol'] = 0.00000001
                nn.update_and_refit_model()
                nn.tune_hyper_parameter('max_iter', np.arange(1, 1000, 100), "KMeans")

                nn.model_params['max_iter'] = 100
                kmeans_loss_curve = nn.plot_epochs_vs_iterations()

                kmeans_nn_score = nn.run_cross_val_on_test_set("Neural Network")

                kmeans_nn_train_times, kmeans_nn_test_times, _ = nn.generate_learning_curves(
                    "Final CV Learning Curve - KMeans",
                    "Artificial Neural Network")

            if run_gmm_nn:

                # Features are probabilites belonging to each cluster
                x_reduced = gmm_model.predict_proba(X_train_transformed)

                ann = NeuralNetworkModel.NeuralNetworkModel(X_train_transformed, X_test, y_train, y_test, pipe,
                                                           None, ["No DR", "DR"], "DR", OUTPUT,
                                                           "EM", em_model=gmm_model)
                ann.model_params['solver'] = 'sgd'
                ann.model_params['max_iter'] = 1000
                ann.model_params['learning_rate_init'] = 0.004
                ann.model_params['hidden_layer_sizes'] = (12)
                #ann.model_params['learning_rate_init'] = 0.006
                ann.model_params['hidden_layer_sizes'] = (12)
                ann.model_params['tol'] = 0.000001

                param_range = [(12),(14), (12, 2), (12, 4), (12,6)]
                #ann.update_and_refit_model()
                #ann.tune_hyper_parameter('hidden_layer_sizes', param_range, "Artificial Neural Network", 2)

                #param_range = [0.003, 0.004, 0.005, 0.006, 0.007, 0.008 ,0.009]
                #ann.tune_hyper_parameter('learning_rate_init', param_range, "Artificial Neural Network", 2)

                gmm_loss_curve = ann.plot_epochs_vs_iterations()

                gmm_nn_score = ann.run_cross_val_on_test_set("Neural Network")

                gmm_nn_train_times, gmm_nn_test_times, _ = ann.generate_learning_curves(
                    "Final CV Learning Curve - KMeans",
                    "Artificial Neural Network")

            title_dic = {'fontsize': 7, 'fontweight': 'bold'}
            axis_label_size = 7

            fig, (fitness_cp, time_cp) = plt.subplots(1, 2, figsize=(7, 2.2))
            fitness_cp.set_title(
                "Loss vs Iterations NN Tuning", title_dic)
            fitness_cp.set_ylabel("Loss", title_dic)
            fitness_cp.tick_params(axis="x", labelsize=axis_label_size)
            fitness_cp.tick_params(axis="y", labelsize=axis_label_size)
            fitness_cp.set_xlabel("Iteration", title_dic)

            fitness_cp.set_ylim(top=1, bottom=0.3)

            fitness_cp.plot(normal_loss_curve, label="No\nReduction")
            fitness_cp.plot(pca_loss_curve, label="PCA")
            fitness_cp.plot(rp_loss_curve, label="RP")
            fitness_cp.plot(ica_loss_curve, label="ICA")
            fitness_cp.plot(kpca_loss_curve, label="Kernel\nPCA")
            fitness_cp.plot(kmeans_loss_curve, label="KMeans")
            fitness_cp.plot(gmm_loss_curve, label="Features+EM")

            fitness_cp.legend(loc='upper right', ncol=2, fontsize=5.5)

            time_cp.set_xlabel("Time (s)", title_dic)
            time_cp.set_title("Runtime For Training", title_dic)
            time_cp.set_ylabel("Algorithm", title_dic)
            time_cp.tick_params(axis="x", labelsize=axis_label_size)
            time_cp.tick_params(axis="y", labelsize=axis_label_size)

            x = ['No Reduction', 'PCA', 'ICA', 'RP', 'Kernel PCA','KMeans', 'Features + EM']
            x_pos = [i for i, _ in enumerate(x)]
            time_cp.set_yticks(x_pos)
            time_cp.set_yticklabels(x)
            time_cp.barh(x_pos, [normal_nn_train_times[-1], pca_nn_train_times[-1], ica_nn_train_times[-1], rp_nn_train_times[-1], kpca_nn_train_times[-1],kmeans_nn_train_times[-1], gmm_nn_train_times[-1]])

            print("Normal F1 Score: " + str(normal_nn_score))
            print("PCA F1 Score: " + str(pca_nn_score))
            print("ICA F1 Score: " + str(ica_nn_score))
            print("RP F1 Score: " + str(rp_nn_score))
            print("Kernel PCA F1 Score: " + str(kpca_nn_score))
            print("Normal F1 Score: " + str(normal_nn_score))
            print("Kmeans F1 Score: " + str(kmeans_nn_score))
            print("Features + EM F1 Score: " + str(gmm_nn_score))

            time_cp.grid()
            fitness_cp.grid()
            plt.tight_layout()

            path = OUTPUT
            filename = "loss_vs_iteration_part5.png"
            filename = os.path.join(path, filename)
            plt.savefig(filename)

    if dataset2 != "":

        print("Loading dataset " + dataset2)

        # Load the data.
        dataset_csv_path = os.path.join(DATA_PATH, dataset2)
        dataset = pd.read_csv(dataset_csv_path)

        X = dataset.drop("class", axis=1)
        y = dataset["class"].copy()

        numeric_features = list(X.select_dtypes(include=np.number))
        cat_features = list(X.select_dtypes(exclude=np.number))

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1)

        pipe = DataPreprocessor.preprocess_data(X_train)
        X_train_transformed = pipe.fit_transform(X_train)

        enc_cat_features = pipe.named_transformers_['cat'].get_feature_names()
        labels = np.concatenate([numeric_features, enc_cat_features])
        transformed_df_columns = pd.DataFrame(pipe.transform(X_train), columns=labels).columns.tolist()
        transformed_df_columns.append("class")

        if run_part_1:

            OUTPUT = os.getcwd() + "/Output/EarthquakeDataset/Part1"

            PlottingUtils.generate_tsne("TSNE Ground Truth Labels - \n Earthquake Dataset", X_train_transformed, y_train, outdir=OUTPUT)

            k_values = np.arange(2, 100, 1)

            PlottingUtils.plot_k_means_scores(k_values, X_train_transformed, "Normalized Scores of Various Metrics vs K - Earthquake Dataset", outdir=OUTPUT)

            kmeans = KMeans(n_clusters=21, max_iter=500)
            start_time = time.time()
            kmeans.fit_predict(X_train_transformed)
            end_time = time.time()
            runtime = (end_time - start_time) * 1000
            print("Time to fit kmeans original: " + str(runtime) + "ms")

            homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, kmeans.labels_)
            print("Scores for Earthquake Dataset")
            print("K Means")
            print("homogeneity:" + str(homogeneity))
            print("completeness:" + str(completeness))
            print("v measure:" + str(v_measure))
            print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, kmeans.labels_)))
            print()

            PlottingUtils.generate_tsne("TSNE K-Means Clusters - \n Earthquake Dataset", X_train_transformed, kmeans.labels_, outdir=OUTPUT)

            k_values = np.arange(2, 50, 1)
            PlottingUtils.plot_gmm_scores(k_values, X_train_transformed, "BIC & AIC Scores EM - Earthquake Dataset", outdir=OUTPUT)

            gmm = GaussianMixture(6, max_iter=500, n_init=10)
            start_time = time.time()
            gmm.fit(X_train_transformed)
            end_time = time.time()
            runtime = (end_time - start_time) * 1000
            print("Time to fit em original: " + str(runtime) + "ms")

            labels = np.array(gmm.predict(X_train_transformed))

            homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, labels)

            print("EM")
            print("homogeneity:" + str(homogeneity))
            print("completeness:" + str(completeness))
            print("v measure:" + str(v_measure))
            print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, labels)))

            PlottingUtils.generate_tsne("TSNE EM Clusters - \n Earthquake Dataset", X_train_transformed, labels, outdir=OUTPUT)

        pca_reduced_features = None
        ica_reduced_features = None
        rp_reduced_features = None
        kernel_pca_reduced_features = None

        if run_part_2:

            OUTPUT = os.getcwd() + "/Output/EarthquakeDataset/Part2"

            if run_pca:
                # PCA
                PlottingUtils.generate_pca("PCA Explained Variance vs Number of Components \n Earthquake Dataset","PCA Sorted Eigen Values for each Eigen Vector \n Earthquake Dataset", X_train_transformed, 50, outdir=OUTPUT)

                # Best number of components was 8 for PCA
                pca = PCA(n_components=27)
                start_time = time.time()
                pca_reduced_features = pca.fit_transform(X_train_transformed)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit PCA: " + str(runtime) + "ms")

                column_names = ["PC1" , "PC2", "PC3", "PC4", "PC5", "PC6", "PC7", "PC8", "PC9", "PC10", "PC11", "PC12", "PC13", "PC14", "PC15", "PC16", "PC17", "PC18", "PC19", "PC20", "PC21", "PC22", "PC23", "PC24", "PC25", "PC26", "PC27", "class"]

                PlottingUtils.generate_pair_plot("PCA Clusters Earthquake - Dataset", pca_reduced_features,
                                                 y_train, 1, 0, outdir=OUTPUT)
            if run_ica:

                ica_reduced_features, _, _ = PlottingUtils.generate_ica("Average Kurtosis vs # of Components \n Earthquake Dataset", "Kurtosis of each component for 20 Components \n Earthquake Dataset", X_train_transformed, np.arange(1,50,1), OUTPUT, 19, [4, 6, 7, 8, 16, 17, 18, 19])
                column_names = ["ICA Comp 4", "ICA Comp 6", "ICA Comp 7", "ICA Comp 8", "ICa Comp 16", "ICA Comp 17", "ICA Comp 18", "ICA Comp 19", "class"]

                PlottingUtils.generate_pair_plot("ICA Clusters Earthquake - Dataset", ica_reduced_features,
                                                 y_train, 4, 5, outdir=OUTPUT, legend_loc='upper right')

            if run_randomized_projection:

                PlottingUtils.generate_random_projection("Randomized Projection # of Components vs \n Reconstruction MSE over 10 runs", X_train_transformed, np.arange(1,50,1),outdir=OUTPUT)

                rand_proj = GaussianRandomProjection(n_components=25, random_state=1)
                start_time = time.time()
                rp_reduced_features = rand_proj.fit_transform(X_train_transformed)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit RP: " + str(runtime) + "ms")

                column_names = ["RP1", "RP2", "RP3", "RP4", "RP5", "RP6", "RP7", "RP8", "RP9", "RP10", "RP11", "RP12", "RP13", "RP14", "RP15", "RP16", "RP17", "RP18", "RP19", "RP20", "RP21", "RP22", "RP23", "RP24", "RP25",  "class"]

                PlottingUtils.generate_pair_plot("Randomized Projection Clusters Earthquake - Dataset", rp_reduced_features,
                                                 y_train, 12, 6, outdir=OUTPUT, legend_loc='upper right')

            if run_kernel_pca:

                PlottingUtils.generate_kernel_pca("Kernel PCA # of Components vs Explained Variance \n Earthquake Dataset", "Principal Components Poly Degree 3 Kernel \n Earthquake Dataset",X_train_transformed, np.arange(2,50,1),outdir=OUTPUT)

                pca = KernelPCA(n_components=5, kernel='poly', fit_inverse_transform=True, degree=3, n_jobs=-1)
                start_time = time.time()
                kernel_pca_reduced_features = pca.fit_transform(X_train_transformed)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit Kernel PCA: " + str(runtime) + "ms")

                column_names = ["PCA 1", "PCA 2", "PCA 3", "PCA 4", "PCA 5",  "class"]

                PlottingUtils.generate_pair_plot("Kernel PCA Clusters Earthquake - Dataset", kernel_pca_reduced_features,
                                                 y_train, 2, 1, outdir=OUTPUT, legend_loc='upper right')

        if run_part_3:

            OUTPUT = os.getcwd() + "/Output/EarthquakeDataset/Part3"

            if run_pca:

                k_values = np.arange(2, 100, 1)

                PlottingUtils.plot_k_means_scores(k_values, pca_reduced_features, "Normalized Scores of Various Metrics vs K - PCA Reduced \n Earthquake Dataset",outdir=OUTPUT)

                kmeans = KMeans(n_clusters=21, max_iter=500)

                start_time = time.time()
                kmeans.fit_predict(pca_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit kmeans PCA: " + str(runtime) + "ms")

                PlottingUtils.generate_pair_plot("PCA K Means Clusters Earthquake - Dataset", pca_reduced_features,
                                                 kmeans.labels_, 1, 0, outdir=OUTPUT)
                PlottingUtils.generate_pair_plot("Ground Truth Classes Earthquake - Dataset", pca_reduced_features,
                                                 y_train, 1, 0, outdir=OUTPUT)

                PlottingUtils.generate_pair_plot("PCA K Means Clusters Earthquake - Dataset", pca_reduced_features,
                                                 kmeans.labels_, 26, 1, outdir=OUTPUT)
                PlottingUtils.generate_pair_plot("Ground Truth Classes Earthquake - Dataset", pca_reduced_features,
                                                 y_train, 26, 1, outdir=OUTPUT)

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, kmeans.labels_ )
                print("Scores for Earthquake Dataset - PCA Features")
                print("K Means")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, kmeans.labels_)))
                print()

                k_values = np.arange(1, 50, 1)
                PlottingUtils.plot_gmm_scores(k_values, pca_reduced_features, "BIC & AIC Scores EM - PCA Reduced \n Earthquake Dataset",outdir=OUTPUT)

                gmm = GaussianMixture(3, max_iter=500, n_init=10)
                start_time = time.time()
                gmm.fit(pca_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit em PCA: " + str(runtime) + "ms")

                labels = np.array(gmm.predict(pca_reduced_features))

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, labels)

                PlottingUtils.generate_pair_plot("PCA EM Clusters Earthquake - Dataset", pca_reduced_features,
                                                 labels, 1, 0, outdir=OUTPUT)
                PlottingUtils.generate_pair_plot("PCA EM Clusters Earthquake - Dataset", pca_reduced_features,
                                                 labels, 26, 1, outdir=OUTPUT)

                print("EM")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, labels)))

            if run_ica:
                k_values = np.arange(2, 100, 1)

                PlottingUtils.plot_k_means_scores(k_values, ica_reduced_features , "Normalized Scores of Various Metrics vs K - ICA Reduced \n Earthquake Dataset",outdir=OUTPUT)

                kmeans = KMeans(n_clusters=9, max_iter=500)
                start_time = time.time()
                kmeans.fit_predict(ica_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit kmeans ICA: " + str(runtime) + "ms")

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, kmeans.labels_)
                print("Scores for Earthquake Dataset - ICA Features")
                print("K Means")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, kmeans.labels_)))
                print()

                k_values = np.arange(2, 50, 1)
                PlottingUtils.plot_gmm_scores(k_values, ica_reduced_features, "BIC & AIC Scores EM - ICA Reduced \n Earthquake Dataset",outdir=OUTPUT)

                gmm = GaussianMixture(11, max_iter=500, n_init=10)
                start_time = time.time()
                gmm.fit(ica_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit EM ICA: " + str(runtime) + "ms")

                labels = np.array(gmm.predict(ica_reduced_features))

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, labels)

                print("EM")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, labels)))

            if run_randomized_projection:
                k_values = np.arange(2, 100, 1)

                PlottingUtils.plot_k_means_scores(k_values, rp_reduced_features , "Normalized Scores of Various Metrics vs K - Randomized Projection Reduced \n Earthquake Dataset",outdir=OUTPUT)

                kmeans = KMeans(n_clusters=2, max_iter=500)
                start_time = time.time()
                kmeans.fit_predict(rp_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit kmeans RP: " + str(runtime) + "ms")

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train,kmeans.labels_)
                print("Scores for Earthquake Dataset - Randomized Projection Features")
                print("K Means")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, kmeans.labels_)))
                print()

                k_values = np.arange(2, 50, 1)
                PlottingUtils.plot_gmm_scores(k_values, rp_reduced_features, "BIC & AIC Scores EM - Randomized Projection Reduced \n Earthquake Dataset",outdir=OUTPUT)

                gmm = GaussianMixture(11, max_iter=500, n_init=10)
                start_time = time.time()
                gmm.fit(rp_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit em RP: " + str(runtime) + "ms")

                labels = np.array(gmm.predict(rp_reduced_features))

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train,labels)

                print("EM")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, labels)))

            if run_kernel_pca:
                k_values = np.arange(2, 100, 1)

                PlottingUtils.plot_k_means_scores(k_values, kernel_pca_reduced_features , "Normalized Scores of Various Metrics vs K - Kernel PCA Reduced \n Earthquake Dataset",outdir=OUTPUT)

                kmeans = KMeans(n_clusters=4, max_iter=500)
                start_time = time.time()
                kmeans.fit_predict(kernel_pca_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit kmeans Kernel PCA: " + str(runtime) + "ms")

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train,kmeans.labels_)
                print("Scores for Earthquake Dataset - Kernel PCA Reduced Features")
                print("K Means")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, kmeans.labels_)))
                print()

                column_names = ["1", "2", "3", "4", "5", "class"]

                #PlottingUtils.generate_pair_plot(
                #    "Feature Pair Plot - KMeans - Kernel PCA Reduced Features \n - Earthquake Dataset",
                #    kernel_pca_reduced_features, kmeans.labels_, columns=column_names, x_labels=column_names[:-1],
                #    y_labels=column_names[:-1],outdir=OUTPUT)

                k_values = np.arange(2, 50, 1)
                PlottingUtils.plot_gmm_scores(k_values, kernel_pca_reduced_features, "BIC & AIC Scores EM - Kernel PCA Reduced \n Earthquake Dataset",outdir=OUTPUT)

                gmm = GaussianMixture(6, max_iter=500, n_init=10)
                start_time = time.time()
                gmm.fit(kernel_pca_reduced_features)
                end_time = time.time()
                runtime = (end_time - start_time) * 1000
                print("Time to fit EM Kernel PCA: " + str(runtime) + "ms")

                labels = np.array(gmm.predict(kernel_pca_reduced_features))

                homogeneity, completeness, v_measure = homogeneity_completeness_v_measure(y_train, labels)

                print("EM")
                print("homogeneity:" + str(homogeneity))
                print("completeness:" + str(completeness))
                print("v measure:" + str(v_measure))
                print("Adjusted mutual info score:" + str(adjusted_mutual_info_score(y_train, labels)))

    sys.stdout.flush()
    sys.stdout.close()

if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser(description='Args for experiment')
    parser.add_argument('--dataset1', metavar='path', required=False, default="diabetic.csv",
                        help='The path to dataset1')
    parser.add_argument('--dataset2', metavar='path', required=False, default="earthquake_processed.csv",
                        help='The path to dataset2')
    args = parser.parse_args()

    main(dataset1=args.dataset1,
         dataset2=args.dataset2)