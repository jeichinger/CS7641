from sklearn.cluster import KMeans
from matplotlib.ticker import FormatStrFormatter
from sklearn.metrics import silhouette_score
from sklearn.metrics import calinski_harabasz_score
from sklearn.metrics import davies_bouldin_score
from sklearn.preprocessing import MinMaxScaler
import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.decomposition import FastICA
from scipy.stats import kurtosis
from sklearn.random_projection import  GaussianRandomProjection
from sklearn.metrics import mean_squared_error
from sklearn.decomposition import KernelPCA
import time
import matplotlib.cm as cm
from sklearn.manifold import TSNE
DATA_PATH = os.getcwd() + "/Data"
LOG_PATH = os.getcwd() + "/Logs"
OUTPUT = os.getcwd() + "/Output"

SKIP_GRAPH_GEN = False

def plot_k_means_scores(k_range, X_train_transformed, title, outdir):

    if SKIP_GRAPH_GEN:
        return

    inertia_values = []
    silhouette_scores = []
    calinski_scores = []
    davies_score = []
    for k in k_range:
        kmeans = KMeans(n_clusters=k, max_iter=500)
        kmeans.fit_predict(X_train_transformed)
        inertia_values.append(kmeans.inertia_)
        silhouette_scores.append(silhouette_score(X_train_transformed, kmeans.labels_))
        calinski_scores.append(calinski_harabasz_score(X_train_transformed, kmeans.labels_))
        davies_score.append(davies_bouldin_score(X_train_transformed, kmeans.labels_))

    scaler = MinMaxScaler()
    inertia_values = scaler.fit_transform(np.asarray(inertia_values).reshape(-1, 1))
    silhouette_scores = scaler.fit_transform(np.asarray(silhouette_scores).reshape(-1, 1))
    calinski_scores = scaler.fit_transform(np.asarray(calinski_scores).reshape(-1, 1))
    davies_score = scaler.fit_transform(np.asarray(davies_score).reshape(-1, 1))

    title_dic = {'fontsize': 7, 'fontweight': 'bold'}

    fig, (ax1) = plt.subplots(1, 1, figsize=(5, 2))
    ax1.set_xlabel("K", title_dic)
    ax1.set_title(title, title_dic)
    ax1.set_ylabel("Normalized Score/Index", title_dic)
    ax1.tick_params(axis="x", labelsize=7)
    ax1.tick_params(axis="y", labelsize=7)
    ax1.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax1.plot(k_range, inertia_values, label="Inertia", linewidth=2)
    ax1.grid()

    ax1.plot(k_range, silhouette_scores, label="Silhouette Score", linewidth=2)
    ax1.plot(k_range, calinski_scores, label="Calinski-Harabasz Index", linewidth=2)
    ax1.plot(k_range, davies_score, label="Davies-Bouldin Index", linewidth=2)

    ax1.legend(loc='best', fontsize=6)

    plt.tight_layout()
    plt.grid()

    path = os.path.join(outdir)
    filename = title + ".png"
    filename = os.path.join(path, filename)
    plt.savefig(filename)
    plt.close()

def plot_gmm_scores(k_range, X_train_transformed, title, outdir):

    if SKIP_GRAPH_GEN:
        return

    bic_scores = []
    aic_scores = []
    for k in k_range:
        gmm = GaussianMixture(k, max_iter=500, n_init=10)
        gmm.fit(X_train_transformed)
        bic = gmm.bic(X_train_transformed)
        aic = gmm.aic(X_train_transformed)
        bic_scores.append(bic)
        aic_scores.append(aic)

    title_dic = {'fontsize': 7, 'fontweight': 'bold'}

    fig, (ax1) = plt.subplots(1, 1, figsize=(5, 2))
    ax1.set_xlabel("K", title_dic)
    ax1.set_title(title, title_dic)
    ax1.set_ylabel("Score", title_dic)
    ax1.tick_params(axis="x", labelsize=7)
    ax1.tick_params(axis="y", labelsize=7)
    ax1.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax1.plot(k_range, bic_scores, label="BIC", linewidth=2)
    ax1.grid()

    ax1.plot(k_range, aic_scores, label="AIC", linewidth=2)
    ax1.legend(loc='best', fontsize=6)

    plt.tight_layout()
    plt.grid()

    path = os.path.join(outdir)
    filename = title + ".png"
    filename = os.path.join(path, filename)
    plt.savefig(filename)
    plt.close()

def generate_pair_plot(title, X, labels, feat1, feat2, outdir, legend_loc='lower right'):

    if SKIP_GRAPH_GEN:
        return

    #feature = X[:, feat1].reshape((-1,1))
    #labels = np.asarray(labels).reshape((-1,1))
    #data = np.hstack((feature, np.asarray(labels)))
    #df = pd.DataFrame(data, columns=["Feat1", "Class"])

    #df["Feat1"].hist()
    #plt.show()
    #plt.close()

    title_dic = {'fontsize': 7, 'fontweight': 'bold'}

    fig, (ax1) = plt.subplots(1,1, figsize=(3,3))

    cm.get_cmap("gist_rainbow")

    scatter = ax1.scatter(X[:,feat1], X[:,feat2], c=labels, cmap=cm.get_cmap("rainbow"), s= 0.6)

    # produce a legend with the unique colors from the scatter
    legend1 = ax1.legend(*scatter.legend_elements(),
                        loc=legend_loc, title="Classes", fontsize=5, title_fontsize=5)
    ax1.add_artist(legend1)
    ax1.set_title(title, title_dic)
    ax1.set_xlabel("Feature " +str(feat1 + 1), title_dic)
    ax1.set_ylabel("Feature " +str(feat2 + 1), title_dic)
    ax1.tick_params(axis="x", labelsize=4)
    ax1.tick_params(axis="y", labelsize=4)


    #plot = sns.pairplot(df, hue="class", corner=True, diag_kind=None)
    path = os.path.join(outdir)
    filename = title + "Features" + str(feat1) + "_" + str(feat2)
    filename = os.path.join(path, filename)
    plt.savefig(filename)
    plt.close()

def generate_tsne(title, X, labels, outdir):

    if SKIP_GRAPH_GEN:
        return

    fig, (ax1) = plt.subplots(1, 1, figsize=(2.5, 2.5))
    title_dic = {'fontsize': 7, 'fontweight': 'bold'}

    tsne = TSNE(n_components=2, init='pca', random_state=0)

    transformed = tsne.fit_transform(X)

    scatter = ax1.scatter(transformed[:,0], transformed[:,1], c=labels, cmap=cm.get_cmap("rainbow"), s= 0.6)
    ax1.set_title(title, title_dic)
    ax1.tick_params(axis="x", labelsize=4)
    ax1.tick_params(axis="y", labelsize=4)
    path = os.path.join(outdir)
    filename = title
    filename = os.path.join(path, filename)
    plt.savefig(filename)

def generate_pca(title1, title2, X, max_componengts, outdir, desired_variance=0.95,):

    if SKIP_GRAPH_GEN:
        return

    pca = PCA(n_components=max_componengts)
    pca.fit(X)
    cumsum = np.cumsum(pca.explained_variance_ratio_)
    range = np.arange(1, max_componengts+1, 1, dtype=int)

    title_dic = {'fontsize': 7, 'fontweight': 'bold'}

    fig, (ax2,ax1) = plt.subplots(1, 2, figsize=(6, 2))
    ax1.set_xlabel("# of Components", title_dic)
    ax1.set_title(title1, title_dic)
    ax1.set_ylabel("Explained Variance", title_dic)
    ax1.tick_params(axis="x", labelsize=7)
    ax1.tick_params(axis="y", labelsize=7)
    ax1.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax1.set_xticks(range)
    ax1.set_xticklabels(range)

    x_value = np.interp(desired_variance, cumsum, range)
    x_value = np.floor(x_value)

    ax1.plot([x_value, x_value, 1], [0, desired_variance, desired_variance], linewidth=1, color='k', linestyle='dashed', label=str(desired_variance) + "\nExplained Variance")

    ax1.plot(range, cumsum, linewidth=2, label="Explained \n Variance")
    ax1.legend(loc='lower right', fontsize=6)
    ax1.grid()

    ax2.set_xlabel("Principal Component", title_dic)
    ax2.set_title(title2, title_dic)
    ax2.set_ylabel("Eigen Value", title_dic)
    ax2.tick_params(axis="x", labelsize=7)
    ax2.tick_params(axis="y", labelsize=7)
    ax2.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax2.grid()

    if max_componengts < 40:
        ax2.set_xticks(range)
        ax2.set_xticklabels(range)
    else:
        ax2.set_xticks([1, 5, 10, 15, 20,25, 30, 35, 40, 45, 50])
        ax1.set_xticks([1, 5, 10, 15, 20,25, 30, 35, 40, 45, 50])

    ax2.bar(range, pca.explained_variance_)


    plt.tight_layout()

    path = os.path.join(outdir)
    filename = title1 + ".png"
    filename = os.path.join(path, filename)
    plt.savefig(filename)
    plt.close()

def generate_ica(title1, title2, X, param_range, outdir, found_n_components=0, selected_components = None):

    average_kurtosis_values = []
    for n_components in param_range:

        ica = FastICA(n_components=n_components, max_iter=500, random_state=1)
        components = ica.fit_transform(X)

        kurt = kurtosis(components, axis=0)
        kurt = np.mean(kurt)
        kurt = np.abs(kurt)
        average_kurtosis_values.append(kurt)
        #print("Average Kurtosis for " + str(n_components) + ": " + str(kurt))

    ica = FastICA(n_components=found_n_components, max_iter=500, random_state=1)
    start_time = time.time()
    components = ica.fit_transform(X)
    end_time = time.time()
    runtime = (end_time - start_time) * 1000
    print("Time to fit ICA: " + str(runtime) + "ms")
    kurt = kurtosis(components, axis=0)

    title_dic = {'fontsize': 7, 'fontweight': 'bold'}

    fig, (ax1,ax2) = plt.subplots(1, 2, figsize=(6, 2))
    ax1.set_xlabel("# of Components", title_dic)
    ax1.set_title(title1, title_dic)
    ax1.set_ylabel("Average Kurtosis", title_dic)
    ax1.tick_params(axis="x", labelsize=7)
    ax1.tick_params(axis="y", labelsize=7)
    ax1.grid()
    ax1.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

    if param_range[-1] < 40:
        ax1.set_xticks(param_range)
        ax1.set_xticklabels(param_range)
    else:
        ax1.set_xticks([1, 5, 10, 15, 20,25, 30, 35, 40, 45, 50])

    ax1.plot(param_range, average_kurtosis_values, linewidth=2)

    range = np.arange(1, found_n_components+1, 1)

    ax2.set_xlabel("Component", title_dic)
    ax2.set_title(title2, title_dic)
    ax2.set_ylabel("Kurtosis", title_dic)
    ax2.tick_params(axis="x", labelsize=7)
    ax2.tick_params(axis="y", labelsize=7)
    ax2.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax2.set_xticks(range)
    ax2.set_xticklabels(range)
    ax2.bar(range, kurt)
    ax2.grid()


    rects = ax2.patches

    for rect in rects:

        if rect.get_x() + rect.get_width() / 2 in selected_components:

            if param_range[-1] < 40:
                ax2.text(rect.get_x() + rect.get_width() / 2, rect.get_height()-50, "*", ha='center', va='bottom', color='red')
            else:
                ax2.text(rect.get_x() + rect.get_width() / 2, rect.get_height() - 350, "*", ha='center', va='bottom',
                         color='red')

    plt.tight_layout()
    plt.grid()

    path = os.path.join(outdir)
    filename = title1 + ".png"
    filename = os.path.join(path, filename)
    plt.savefig(filename)
    plt.close()

    selected_components = np.array(selected_components)

    selected_components = selected_components-1

    return components[:,selected_components], ica, selected_components

def generate_random_projection(title1, X, param_range, outdir):

    if SKIP_GRAPH_GEN:
        return

    reconstruction_errors = []
    runs = []

    for i in range(10):

        reconstruction_errors = []
        for components in param_range:

            rand_proj = GaussianRandomProjection(n_components=components, random_state=i)
            reduced_x = rand_proj.fit_transform(X)
            inverse_x = np.linalg.pinv(rand_proj.components_.T)
            reconstructed = reduced_x.dot(inverse_x)

            mse = mean_squared_error(X, reconstructed)
            reconstruction_errors.append(mse)

        runs.append(reconstruction_errors)

    title_dic = {'fontsize': 7, 'fontweight': 'bold'}

    fig, (ax1,ax2) = plt.subplots(1, 2, figsize=(6, 2))
    ax2.axis('off')
    ax1.set_xlabel("# of Components", title_dic)
    ax1.set_title(title1, title_dic)
    ax1.set_ylabel("Reconstruction MSE", title_dic)
    ax1.tick_params(axis="x", labelsize=7)
    ax1.tick_params(axis="y", labelsize=7)
    ax1.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

    if param_range[-1] < 40:
        ax1.set_xticks(param_range)
        ax1.set_xticklabels(param_range)
    else:
        ax1.set_xticks([1, 5, 10, 15, 20,25, 30, 35, 40, 45, 50])

    runs_mean = np.mean(runs, axis=0)
    runs_std = np.std(runs, axis=0)

    ax1.fill_between(param_range, runs_mean - runs_std,
                     runs_mean + runs_std, alpha=0.5,lw=1)

    ax1.plot(param_range, runs_mean, linewidth=2)

    plt.tight_layout()

    path = os.path.join(outdir)
    filename = title1 + ".png"
    filename = os.path.join(path, filename)
    plt.savefig(filename)
    plt.close()

def generate_kernel_pca(title1, title2, X, param_range, outdir):

    if SKIP_GRAPH_GEN:
        return

    kernel_pca = KernelPCA(n_components=param_range[-1], kernel='linear', fit_inverse_transform=True, n_jobs=-1)
    kernel_pca.fit(X)
    linear_explained_variance = kernel_pca.lambdas_ / np.sum(kernel_pca.lambdas_)
    linear_cumsum = np.cumsum(linear_explained_variance)

    kernel_pca = KernelPCA(n_components=param_range[-1], kernel='rbf', fit_inverse_transform=False, n_jobs=-1)
    kernel_pca.fit(X)
    rbf_explained_variance = kernel_pca.lambdas_ / np.sum(kernel_pca.lambdas_)
    rbf_cumsum = np.cumsum(rbf_explained_variance)

    kernel_pca = KernelPCA(n_components=param_range[-1], kernel='poly', degree=2, fit_inverse_transform=False, n_jobs=-1)
    kernel_pca.fit(X)
    poly_2_explained_variance = kernel_pca.lambdas_ / np.sum(kernel_pca.lambdas_)
    poly_2_cumsum = np.cumsum(poly_2_explained_variance)

    poly_3_kernel_pca = KernelPCA(n_components=param_range[-1], kernel='poly', degree=3, fit_inverse_transform=False, n_jobs=-1)
    poly_3_kernel_pca.fit(X)
    poly_3_explained_variance = poly_3_kernel_pca.lambdas_ / np.sum(poly_3_kernel_pca.lambdas_)
    poly_3_cumsum = np.cumsum(poly_3_explained_variance)

    kernel_pca = KernelPCA(n_components=param_range[-1], kernel='sigmoid', fit_inverse_transform=True, n_jobs=-1)
    kernel_pca.fit(X)
    sigmoid_explained_variance = kernel_pca.lambdas_ / np.sum(kernel_pca.lambdas_)
    sigmoid_cumsum = np.cumsum(sigmoid_explained_variance)

    range = np.arange(1, param_range[-1]+1, 1, dtype=int)

    title_dic = {'fontsize': 7, 'fontweight': 'bold'}

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6, 2))
    ax1.set_xlabel("# of Components", title_dic)
    ax1.set_title(title1, title_dic)
    ax1.set_ylabel("Explained Variance", title_dic)
    ax1.tick_params(axis="x", labelsize=7)
    ax1.tick_params(axis="y", labelsize=7)
    ax1.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax1.set_xticks(range)
    ax1.set_xticklabels(range)

    #x_value = np.interp(0.95, cumsum, range)
    #x_value = np.floor(x_value)

    #ax1.plot([x_value, x_value, 1], [0, desired_variance, desired_variance], linewidth=1, color='k', linestyle='dashed',
    #         label=str(desired_variance) + "\nExplained Variance")

    ax1.plot(range, rbf_cumsum, linewidth=2, label="RBF")
    ax1.plot(range, poly_3_cumsum, linewidth=2, label="Poly-Degree 3")
    ax1.plot(range, poly_2_cumsum, linewidth=2, label="Poly-Degree 2")
    ax1.plot(range, sigmoid_cumsum, linewidth=2, label="Sigmoid")
    ax1.plot(range, linear_cumsum, linewidth=2, label="Linear")
    ax1.plot(range, np.ones(range.shape) * 0.95, linewidth=1, label="0.95 Explained Variance", color= 'k', linestyle='dashed')
    ax1.legend(loc='lower right', fontsize=6)
    ax1.grid()

    ax2.set_xlabel("Principal Component", title_dic)
    ax2.set_title(title2, title_dic)
    ax2.set_ylabel("Eigen Value", title_dic)
    ax2.tick_params(axis="x", labelsize=7)
    ax2.tick_params(axis="y", labelsize=7)
    ax2.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax2.grid()

    if param_range[-1] < 40:
        ax2.set_xticks(range)
        ax2.set_xticklabels(range)
        ax2.bar(range,poly_3_kernel_pca.lambdas_)
    else:
        ax2.set_xticks([1, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50])
        ax1.set_xticks([1, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50])

        ax2.bar(range,poly_3_kernel_pca.lambdas_)
    ax2.grid()

    plt.tight_layout()
    plt.grid()

    path = os.path.join(outdir)
    filename = title1 + ".png"
    filename = os.path.join(path, filename)
    plt.savefig(filename)
    plt.close()
